export type EquipmentCategory = 'immobilisation' | 'rachis' | 'membres' | 'divers';

export interface Equipment {
  id: string;
  name: string;
  category: EquipmentCategory;
  unit: string;
  defaultMinThreshold: number;
  description?: string;
  active: boolean;
}

export type LocationType = 'patrol_base' | 'medical_cabinet' | 'hospital' | 'maintenance';

export interface Location {
  id: string;
  name: string;
  type: LocationType;
  isInternalBase: boolean;
  altitude?: number;
  contact?: string;
  active: boolean;
}

export interface EquipmentQuantity {
  equipmentId: string;
  quantity: number;
}

export interface DeductionRule {
  id: string;
  injuryKey: string;
  injuryLabel: string;
  description: string;
  defaultEquipments: EquipmentQuantity[];
}

export type EvacuationType = 'direct' | 'transit_central';

export interface RescueIncident {
  id: string;
  number: number;
  timestamp: string;
  patrolBaseId: string;
  injuryKey: string;
  evacuationType: EvacuationType;
  intermediateLocationId?: string;
  finalDestinationId: string;
  equipmentsUsed: EquipmentQuantity[];
  victimRef?: string;
  notes?: string;
}

export type MovementType = 
  | 'rescue_dispatch' 
  | 'rescue_transit' 
  | 'quick_return' 
  | 'closing_recovery' 
  | 'inter_base_transfer'
  | 'incident_cancellation'
  | 'flagged_damaged' 
  | 'maintenance_repaired' 
  | 'manual_audit';

export interface MovementLog {
  id: string;
  timestamp: string;
  equipmentId: string;
  quantity: number;
  fromLocationId: string;
  toLocationId: string;
  incidentId?: string;
  type: MovementType;
  notes?: string;
}

export interface AppState {
  locations: Location[];
  equipments: Equipment[];
  deductionRules: DeductionRule[];
  incidents: RescueIncident[];
  movements: MovementLog[];
  // locationId -> equipmentId -> count
  stocks: Record<string, Record<string, number>>;
  // locationId -> equipmentId -> min threshold
  minThresholds: Record<string, Record<string, number>>;
}
