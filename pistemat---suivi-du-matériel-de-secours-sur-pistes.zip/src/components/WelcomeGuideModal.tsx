import React from 'react';
import { 
  X, 
  Mountain, 
  PlusCircle, 
  RotateCcw, 
  Clock, 
  FileText, 
  ShieldCheck, 
  ArrowRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface WelcomeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WelcomeGuideModal: React.FC<WelcomeGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700/80 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden text-slate-900 dark:text-slate-100 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* En-tête */}
        <div className="px-5 py-4 sm:px-6 sm:py-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-gradient-to-r dark:from-sky-950/60 dark:via-slate-900 dark:to-slate-900 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-sky-100 dark:bg-sky-500/10 border border-sky-300 dark:border-sky-400/30 flex items-center justify-center text-sky-700 dark:text-sky-400 shrink-0 shadow-inner">
              <Mountain className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Bienvenue sur PisteMat
                </h2>
                <span className="text-[10px] font-bold tracking-wider uppercase text-sky-900 bg-sky-100 border border-sky-300 dark:text-sky-300 dark:bg-sky-950 dark:border-sky-800/80 rounded px-1.5 py-0.5">
                  Secours Pistes
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                Guide de prise en main du suivi opérationnel de matériel
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Corps du message scrollable */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-sm">
          {/* Section 1 : Ce que fait l'application */}
          <div className="bg-sky-50 dark:bg-slate-950/70 border border-sky-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-2xs">
            <div className="flex items-center gap-2.5 text-sky-700 dark:text-sky-400 font-bold mb-2">
              <Sparkles className="w-4 h-4 shrink-0" />
              <h3 className="text-xs uppercase tracking-wider font-extrabold">Ce que fait PisteMat</h3>
            </div>
            <p className="text-slate-800 dark:text-slate-300 leading-relaxed text-xs sm:text-sm">
              <strong className="text-slate-950 dark:text-white font-bold">PisteMat</strong> est l'application opérationnelle conçue pour le service des pistes de ski afin de tracer et gérer le matériel de secours d'altitude (MID, matelas coquille, attelles à dépression, colliers cervicaux, brancards...) <strong className="text-sky-800 dark:text-sky-300 font-bold">sans code-barres ni scan QR code</strong>, difficilement utilisables sur la neige.
            </p>
            <p className="text-slate-600 dark:text-slate-400 text-xs mt-2 leading-relaxed">
              Dès qu'un blessé est évacué avec du matériel vers un cabinet médical ou un hôpital de vallée, l'application déduit automatiquement les pièces sorties pour vous éviter toute rupture de stock en altitude.
            </p>
          </div>

          {/* Section 2 : Fonctionnalités principales */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 dark:text-slate-200 font-bold">
              <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-xs uppercase tracking-wider font-extrabold">Les 4 fonctionnalités principales</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Secours */}
              <div className="bg-rose-50/70 dark:bg-slate-950/60 border border-rose-300 dark:border-red-900/40 rounded-xl p-3.5 space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 text-rose-800 dark:text-red-400 font-bold text-xs sm:text-sm">
                  <PlusCircle className="w-4 h-4 shrink-0" />
                  <span>1. Nouveau Secours (Bouton Rouge)</span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  Enregistrez une intervention en quelques secondes. Le matériel engagé est aussitôt déduit du poste de départ et localisé chez le destinataire.
                </p>
              </div>

              {/* Rapatriement */}
              <div className="bg-emerald-50/70 dark:bg-slate-950/60 border border-emerald-300 dark:border-emerald-900/40 rounded-xl p-3.5 space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-400 font-bold text-xs sm:text-sm">
                  <RotateCcw className="w-4 h-4 shrink-0" />
                  <span>2. Rapatriement (Bouton Vert)</span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  Quand le cabinet médical ou l'ambulance vous rend du matériel, réintégrez-le en un clic dans le poste de votre choix ou signalez une avarie.
                </p>
              </div>

              {/* Postes & Stocks */}
              <div className="bg-sky-50/70 dark:bg-slate-950/60 border border-sky-300 dark:border-sky-900/40 rounded-xl p-3.5 space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 text-sky-800 dark:text-sky-400 font-bold text-xs sm:text-sm">
                  <Mountain className="w-4 h-4 shrink-0" />
                  <span>3. Postes & Stocks en Direct</span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  Visualisez en temps réel les disponibilités par poste d'altitude. Un voyant d'alerte rouge vous prévient si un stock descend sous le seuil d'alerte.
                </p>
              </div>

              {/* Fermeture & Main courante */}
              <div className="bg-amber-50/70 dark:bg-slate-950/60 border border-amber-300 dark:border-amber-900/40 rounded-xl p-3.5 space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 text-amber-800 dark:text-amber-400 font-bold text-xs sm:text-sm">
                  <Clock className="w-4 h-4 shrink-0" />
                  <span>4. Fermeture 17h & Journal</span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  À la fin du service, faites le point sur tout le matériel resté dehors, effectuez un rapatriement groupé et consultez la main courante modifiable.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3 : Par où commencer ? */}
          <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-sky-800/40 rounded-xl p-4 sm:p-5 space-y-3 shadow-2xs">
            <div className="flex items-center gap-2 text-sky-800 dark:text-sky-300 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <h3 className="text-xs uppercase tracking-wider font-extrabold">Par où commencer ? (3 étapes simples)</h3>
            </div>

            <ol className="space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              <li className="flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-sky-600 text-white font-bold text-[11px] shrink-0 mt-0.5">
                  1
                </span>
                <span>
                  <strong className="text-slate-950 dark:text-white">Vérifiez vos postes :</strong> Allez sur l'onglet <span className="text-sky-700 dark:text-sky-300 font-bold">"Postes & Stocks"</span> pour observer les niveaux de matériel disponibles par cabane de secours.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-rose-600 text-white font-bold text-[11px] shrink-0 mt-0.5">
                  2
                </span>
                <span>
                  <strong className="text-slate-950 dark:text-white">Déclarez un secours :</strong> Cliquez sur le bouton rouge en haut <span className="text-rose-700 dark:text-red-400 font-extrabold">"Nouveau Secours"</span> pour enregistrer une sortie de MID ou de collier.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] shrink-0 mt-0.5">
                  3
                </span>
                <span>
                  <strong className="text-slate-950 dark:text-white">Enregistrez un retour :</strong> Dès qu'un équipement revient de la clinique, cliquez sur le bouton vert <span className="text-emerald-700 dark:text-emerald-400 font-extrabold">"Rapatriement"</span> pour le réaffecter au stock.
                </span>
              </li>
            </ol>
          </div>
        </div>

        {/* Pied de modale */}
        <div className="p-4 sm:px-6 sm:py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/90 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1.5 text-center sm:text-left">
            <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            Ce guide reste accessible à tout moment via le bouton "Guide / Aide".
          </span>
          <button
            onClick={onClose}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer active:scale-95"
          >
            <span>Commencer à utiliser PisteMat</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
