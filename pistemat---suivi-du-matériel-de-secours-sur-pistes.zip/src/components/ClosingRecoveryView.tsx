import React from 'react';
import { 
  Clock, 
  RotateCcw, 
  CheckCircle2, 
  Building2, 
  Hospital, 
  Wrench, 
  FileSpreadsheet
} from 'lucide-react';
import { AppState, Equipment, Location } from '../types';
import { exportMovementsToCSV, exportStockInventoryToCSV } from '../lib/storage';

interface ClosingRecoveryViewProps {
  state: AppState;
  onExecuteBulkRecovery: (fromLocationId: string, toLocationId: string) => void;
  onOpenQuickReturnWithParams: (fromLocationId: string, equipmentId: string) => void;
}

export const ClosingRecoveryView: React.FC<ClosingRecoveryViewProps> = ({
  state,
  onExecuteBulkRecovery,
  onOpenQuickReturnWithParams,
}) => {
  const centralBase = state.locations.find(l => l.id === 'loc_central') || state.locations[0];
  const externalLocations = state.locations.filter(l => !l.isInternalBase && l.active);

  // Group items currently detained outside
  const detainedItems: {
    location: Location;
    items: { equipment: Equipment; quantity: number }[];
    totalQuantity: number;
  }[] = [];

  let grandTotalOutside = 0;

  externalLocations.forEach(loc => {
    const items: { equipment: Equipment; quantity: number }[] = [];
    let locTotal = 0;

    (state.equipments || []).filter(e => e.active).forEach(eq => {
      const qty = state.stocks?.[loc.id]?.[eq.id] ?? 0;
      if (qty > 0) {
        items.push({ equipment: eq, quantity: qty });
        locTotal += qty;
        grandTotalOutside += qty;
      }
    });

    if (locTotal > 0 || loc.type === 'medical_cabinet' || loc.type === 'hospital') {
      detainedItems.push({
        location: loc,
        items,
        totalQuantity: locTotal,
      });
    }
  });

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Header Banner Clôture */}
      <div className="bg-white dark:bg-gradient-to-r dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-5 transition-colors">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold text-amber-950 bg-amber-100 border border-amber-300 dark:text-amber-300 dark:bg-amber-950/70 dark:border-amber-700/60 flex-wrap">
            <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>Procédure de Fin de Journée &middot; Fermeture des Remontées</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Checklist de Rapatriement du Matériel
          </h2>
          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            Avant le départ des navettes et la fermeture du poste central, pointez le matériel restitué par les partenaires médicaux pour que tous les postes d'altitude soient prêts pour l'ouverture de demain matin.
          </p>
        </div>

        {/* Global Status Pill & CSV Exports */}
        <div className="shrink-0 flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-3">
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50 dark:bg-slate-900/90 border border-slate-300 dark:border-slate-800 flex items-center gap-3 shadow-2xs">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              grandTotalOutside === 0
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/40'
                : 'bg-amber-100 text-amber-800 border border-amber-300 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/40'
            }`}>
              {grandTotalOutside === 0 ? <CheckCircle2 className="w-6 h-6" /> : <RotateCcw className="w-6 h-6" />}
            </div>
            <div>
              <div className="text-xs text-slate-600 dark:text-slate-400 font-medium">Matériel hors station :</div>
              <div className="text-xl sm:text-2xl font-black font-mono text-slate-900 dark:text-white tabular-nums">
                {grandTotalOutside} <span className="text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400 font-sans">pièce(s) dehors</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 w-full sm:w-auto">
            <button
              onClick={() => exportStockInventoryToCSV(state)}
              className="px-3.5 py-2 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer min-h-[38px] shadow-2xs"
            >
              <FileSpreadsheet className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <span className="truncate">Stocks (CSV)</span>
            </button>
            <button
              onClick={() => exportMovementsToCSV(state.movements, state.equipments, state.locations, state.incidents)}
              className="px-3.5 py-2 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer min-h-[38px] shadow-2xs"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="truncate">Journal (CSV)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Liste des Lieux avec matériel à récupérer */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <span>Pointage des Lieux Extérieurs</span>
          </h3>
          <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 px-3 py-1 rounded-lg">
            Destination : {centralBase.name.split('(')[0]}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {detainedItems.map(group => {
            const hasItems = group.items.length > 0;
            return (
              <div
                key={group.location.id}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm dark:shadow-lg flex flex-col justify-between space-y-4 transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        group.location.type === 'hospital'
                          ? 'bg-sky-100 text-sky-700 border border-sky-300 dark:bg-sky-500/10 dark:text-sky-400 dark:border-sky-500/30'
                          : group.location.type === 'maintenance'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/30'
                          : 'bg-teal-100 text-teal-800 border border-teal-300 dark:bg-teal-500/10 dark:text-teal-400 dark:border-teal-500/30'
                      }`}>
                        {group.location.type === 'hospital' ? (
                          <Hospital className="w-4 h-4" />
                        ) : group.location.type === 'maintenance' ? (
                          <Wrench className="w-4 h-4" />
                        ) : (
                          <Building2 className="w-4 h-4" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white truncate">{group.location.name}</h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
                          {group.location.contact || 'Partenaire médical'}
                        </p>
                      </div>
                    </div>

                    <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-lg border shrink-0 ${
                      hasItems
                        ? 'text-amber-950 bg-amber-100 border-amber-300 dark:text-amber-300 dark:bg-amber-950 dark:border-amber-800'
                        : 'text-emerald-950 bg-emerald-100 border-emerald-300 dark:text-emerald-400 dark:bg-emerald-950 dark:border-emerald-800'
                    }`}>
                      {group.totalQuantity} pièces
                    </span>
                  </div>

                  {/* List of items */}
                  <div className="py-3.5 space-y-2 text-xs sm:text-sm">
                    {hasItems ? (
                      group.items.map(item => (
                        <div
                          key={item.equipment.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 gap-2"
                        >
                          <span className="font-semibold text-slate-900 dark:text-slate-200 truncate">
                            {item.equipment.name.split('(')[0]}
                          </span>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="font-mono font-bold text-amber-800 dark:text-amber-400 text-sm">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onOpenQuickReturnWithParams(group.location.id, item.equipment.id)}
                              className="px-2.5 py-1 text-xs font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg border border-slate-300 dark:border-slate-700 flex items-center gap-1.5 transition-colors min-h-[30px] cursor-pointer shadow-2xs"
                              title="Rapatrier 1 unité vers le Poste Central"
                            >
                              <RotateCcw className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                              <span>1x Rapatrier</span>
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex items-center justify-center gap-2 py-4 text-emerald-700 dark:text-emerald-400 font-semibold text-sm">
                        <CheckCircle2 className="w-5 h-5" />
                        <span>Tout le matériel est rentré</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bulk recovery action */}
                {hasItems && (
                  <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => onExecuteBulkRecovery(group.location.id, centralBase.id)}
                      className="w-full py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm bg-emerald-600 hover:bg-emerald-500 text-white shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer min-h-[42px]"
                    >
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span className="truncate">Tout rapatrier au Poste Central ({group.totalQuantity})</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
