import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  FileSpreadsheet, 
  AlertTriangle, 
  ArrowRight, 
  Clock, 
  Edit2, 
  Check, 
  X 
} from 'lucide-react';
import { AppState, MovementLog } from '../types';
import { exportMovementsToCSV } from '../lib/storage';

interface HistoryViewProps {
  state: AppState;
  onCancelIncident: (incidentId: string, reason: string) => void;
  onUpdateMovement?: (
    movementId: string,
    updatedData: {
      equipmentId: string;
      quantity: number;
      fromLocationId: string;
      toLocationId: string;
      notes?: string;
      timestamp?: string;
    }
  ) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  state,
  onCancelIncident,
  onUpdateMovement,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [cancellingIncidentId, setCancellingIncidentId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('Fausse alerte / Annulation pisteurs');

  // Edit movement entry state
  const [editingMovement, setEditingMovement] = useState<MovementLog | null>(null);
  const [editEquipmentId, setEditEquipmentId] = useState<string>('');
  const [editQuantity, setEditQuantity] = useState<number>(1);
  const [editFromLocId, setEditFromLocId] = useState<string>('');
  const [editToLocId, setEditToLocId] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');

  const eqMap = new Map(state.equipments.map(e => [e.id, e.name]));
  const locMap = new Map(state.locations.map(l => [l.id, l.name]));
  const incMap = new Map(state.incidents.map(i => [i.id, i.number]));

  const getRescueLabel = (incidentId?: string) => {
    if (!incidentId) return null;
    const num = incMap.get(incidentId);
    return num !== undefined ? `Secours #${num}` : `Secours #${incidentId.replace('inc_', '')}`;
  };

  const typeConfig: Record<string, { label: string; badge: string }> = {
    rescue_dispatch: { label: 'Secours - Déduction', badge: 'text-sky-950 bg-sky-100 border-sky-300 dark:text-sky-300 dark:bg-sky-950/80 dark:border-sky-800' },
    rescue_transit: { label: 'Transit Secours', badge: 'text-sky-900 bg-sky-50 border-sky-300 dark:text-sky-200 dark:bg-sky-950 dark:border-sky-800' },
    quick_return: { label: 'Rapatriement', badge: 'text-emerald-950 bg-emerald-100 border-emerald-300 dark:text-emerald-300 dark:bg-emerald-950/80 dark:border-emerald-800' },
    closing_recovery: { label: 'Fermeture Pistes', badge: 'text-teal-950 bg-teal-100 border-teal-300 dark:text-teal-300 dark:bg-teal-950/80 dark:border-teal-800' },
    inter_base_transfer: { label: 'Renfort Inter-Postes', badge: 'text-indigo-950 bg-indigo-100 border-indigo-300 dark:text-indigo-300 dark:bg-indigo-950/80 dark:border-indigo-800' },
    flagged_damaged: { label: 'Avarie / Atelier', badge: 'text-amber-950 bg-amber-100 border-amber-300 dark:text-amber-300 dark:bg-amber-950/80 dark:border-amber-800' },
    maintenance_repaired: { label: 'Retour Atelier', badge: 'text-emerald-950 bg-emerald-100 border-emerald-300 dark:text-emerald-300 dark:bg-emerald-950/80 dark:border-emerald-800' },
    manual_audit: { label: 'Ajustement Inventaire', badge: 'text-purple-950 bg-purple-100 border-purple-300 dark:text-purple-300 dark:bg-purple-950/80 dark:border-purple-800' },
    incident_cancellation: { label: 'Annulation Secours', badge: 'text-rose-950 bg-rose-100 border-rose-300 dark:text-rose-300 dark:bg-rose-950/80 dark:border-rose-800' },
  };

  const cancelledIncidentIds = new Set<string>();
  state.incidents.forEach(inc => {
    if (inc.notes?.includes('[ANNULÉ]')) cancelledIncidentIds.add(inc.id);
  });
  state.movements.forEach(m => {
    if (m.type === 'incident_cancellation' && m.incidentId) {
      cancelledIncidentIds.add(m.incidentId);
    }
  });

  // Filtered movements sorted by timestamp descending
  const filteredMovements = state.movements
    .filter(m => {
      if (selectedType !== 'all' && m.type !== selectedType) return false;
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      const eqName = (eqMap.get(m.equipmentId) || '').toLowerCase();
      const fromName = (locMap.get(m.fromLocationId) || '').toLowerCase();
      const toName = (locMap.get(m.toLocationId) || '').toLowerCase();
      const notes = (m.notes || '').toLowerCase();
      const inc = (m.incidentId || '').toLowerCase();
      return eqName.includes(q) || fromName.includes(q) || toName.includes(q) || notes.includes(q) || inc.includes(q);
    })
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const handleOpenEdit = (m: MovementLog) => {
    setEditingMovement(m);
    setEditEquipmentId(m.equipmentId);
    setEditQuantity(m.quantity);
    setEditFromLocId(m.fromLocationId);
    setEditToLocId(m.toLocationId);
    setEditNotes(m.notes || '');
    setEditDate(m.timestamp);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMovement || !onUpdateMovement) return;

    onUpdateMovement(editingMovement.id, {
      equipmentId: editEquipmentId,
      quantity: editQuantity,
      fromLocationId: editFromLocId,
      toLocationId: editToLocId,
      notes: editNotes.trim() || undefined,
      timestamp: editDate,
    });

    setEditingMovement(null);
  };

  const handleConfirmCancel = () => {
    if (!cancellingIncidentId) return;
    onCancelIncident(cancellingIncidentId, cancelReason);
    setCancellingIncidentId(null);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>Main Courante & Traçabilité des Mouvements</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Historique complet, horodaté et modifiable des déductions, rapatriements et transferts
          </p>
        </div>

        <button
          onClick={() => exportMovementsToCSV(state.movements, state.equipments, state.locations, state.incidents)}
          className="w-full sm:w-auto px-4 py-2 text-xs sm:text-sm font-bold text-slate-800 dark:text-white bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl flex items-center justify-center gap-2 shadow-2xs transition-colors cursor-pointer min-h-[38px]"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span>Exporter CSV</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl p-3.5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-2xs transition-colors">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Rechercher par matériel, poste, lieu, mot-clé..."
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
          />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
          <span className="text-xs text-slate-600 dark:text-slate-400 shrink-0 font-medium">Filtrer par type :</span>
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="w-full sm:w-auto bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
          >
            <option value="all">Tous les événements ({state.movements.length})</option>
            <option value="rescue_dispatch">Secours & Déductions</option>
            <option value="quick_return">Rapatriements</option>
            <option value="closing_recovery">Fermeture des pistes</option>
            <option value="inter_base_transfer">Renforts inter-postes</option>
            <option value="flagged_damaged">Avaries & Atelier</option>
            <option value="manual_audit">Ajustements d'inventaire</option>
          </select>
        </div>
      </div>

      {/* MOBILE VIEW (< md): Ergonomic Cards for touchscreens */}
      <div className="block md:hidden space-y-3">
        {filteredMovements.map(m => {
          const conf = typeConfig[m.type] || { label: m.type, badge: 'text-slate-700 bg-slate-100 border-slate-300 dark:text-slate-300 dark:bg-slate-800 dark:border-slate-700' };
          const eqName = eqMap.get(m.equipmentId) || m.equipmentId;
          const fromName = locMap.get(m.fromLocationId) || m.fromLocationId;
          const toName = locMap.get(m.toLocationId) || m.toLocationId;
          const isRescueDispatch = m.type === 'rescue_dispatch' && m.incidentId;

          return (
            <div
              key={m.id}
              className="p-4 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl space-y-3 text-xs sm:text-sm shadow-sm dark:shadow-md transition-colors"
            >
              {/* Card Header: Timestamp & Event Badge */}
              <div className="flex items-center justify-between gap-2">
                <span className={`px-2.5 py-0.5 rounded-lg text-xs font-bold border ${conf.badge}`}>
                  {conf.label}
                </span>
                <span className="font-mono text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  {new Date(m.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} &middot; {new Date(m.timestamp).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
                </span>
              </div>

              {/* Equipment & Quantity */}
              <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
                <span className="font-extrabold text-slate-900 dark:text-white text-base">
                  {eqName.split('(')[0]}
                </span>
                <span className="font-mono font-black text-sky-800 bg-sky-100 border border-sky-300 dark:text-sky-300 dark:bg-sky-950/80 dark:border-sky-800 px-3 py-1 rounded-lg text-sm tabular-nums">
                  Qté : {m.quantity}
                </span>
              </div>

              {/* Trajet: Origine -> Destination */}
              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="truncate font-medium">{fromName.split('(')[0]}</span>
                <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 mx-1" />
                <span className="truncate font-bold text-slate-950 dark:text-white">{toName.split('(')[0]}</span>
              </div>

              {/* Incident info & notes */}
              {(m.incidentId || m.notes) && (
                <div className="flex flex-wrap items-center justify-between gap-1 text-xs text-slate-600 dark:text-slate-400 pt-0.5">
                  {m.incidentId && (
                    <span className="font-mono text-sky-800 dark:text-sky-400 font-bold bg-sky-100 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 px-2 py-0.5 rounded">
                      {getRescueLabel(m.incidentId)}
                    </span>
                  )}
                  {m.notes && (
                    <span className="truncate italic flex-1 text-right ml-2" title={m.notes}>
                      {m.notes}
                    </span>
                  )}
                </div>
              )}

              {/* Actions: Modifier et Annuler */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  onClick={() => handleOpenEdit(m)}
                  className="px-3 py-1.5 text-xs font-bold text-sky-800 hover:text-sky-950 bg-sky-50 hover:bg-sky-100 border border-sky-300 dark:text-sky-300 dark:hover:text-white dark:bg-sky-950/70 dark:hover:bg-sky-900 dark:border-sky-800 rounded-lg transition-colors flex items-center gap-1.5 min-h-[34px] cursor-pointer shadow-2xs"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Modifier</span>
                </button>

                {isRescueDispatch && (
                  <>
                    {cancelledIncidentIds.has(m.incidentId!) ? (
                      <span className="px-2.5 py-1 text-xs font-bold text-rose-800 bg-rose-100 border border-rose-300 dark:text-rose-300 dark:bg-rose-950/50 dark:border-rose-900 rounded-lg">
                        Annulé
                      </span>
                    ) : (
                      <button
                        onClick={() => setCancellingIncidentId(m.incidentId!)}
                        className="px-3 py-1.5 text-xs font-bold text-rose-800 hover:text-rose-950 bg-rose-50 hover:bg-rose-100 border border-rose-300 dark:text-rose-300 dark:hover:text-white dark:bg-rose-950/70 dark:hover:bg-rose-900 dark:border-rose-800 rounded-lg transition-colors min-h-[34px] cursor-pointer shadow-2xs"
                      >
                        Annuler
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })}

        {filteredMovements.length === 0 && (
          <div className="py-8 text-center text-slate-500 italic text-xs sm:text-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-300 dark:border-slate-800 p-6 shadow-sm">
            Aucun mouvement ne correspond aux filtres sélectionnés.
          </div>
        )}
      </div>

      {/* DESKTOP & TABLET VIEW (>= md): Full High-Density Data Table */}
      <div className="hidden md:block bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-lg transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-400 uppercase tracking-wider text-xs font-bold">
                <th className="py-3 px-4">Heure / Date</th>
                <th className="py-3 px-4">Événement</th>
                <th className="py-3 px-4">Matériel</th>
                <th className="py-3 px-4 text-center">Qté</th>
                <th className="py-3 px-4">Trajet (Origine &rarr; Destination)</th>
                <th className="py-3 px-4">Secours / Réf</th>
                <th className="py-3 px-4">Détails & Motifs</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
              {filteredMovements.map(m => {
                const conf = typeConfig[m.type] || { label: m.type, badge: 'text-slate-700 bg-slate-100 border-slate-300 dark:text-slate-300 dark:bg-slate-800 dark:border-slate-700' };
                const eqName = eqMap.get(m.equipmentId) || m.equipmentId;
                const fromName = locMap.get(m.fromLocationId) || m.fromLocationId;
                const toName = locMap.get(m.toLocationId) || m.toLocationId;

                const isRescueDispatch = m.type === 'rescue_dispatch' && m.incidentId;

                return (
                  <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-950/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {new Date(m.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} &middot; {new Date(m.timestamp).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`inline-block px-2.5 py-0.5 rounded-lg text-xs font-bold border ${conf.badge}`}>
                        {conf.label}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-bold text-slate-950 dark:text-white whitespace-nowrap">
                      {eqName.split('(')[0]}
                    </td>

                    <td className="py-3.5 px-4 text-center font-mono font-black text-sky-800 dark:text-sky-300 text-sm tabular-nums">
                      {m.quantity}
                    </td>

                    <td className="py-3.5 px-4 text-xs sm:text-sm whitespace-nowrap">
                      <span className="text-slate-700 dark:text-slate-300 font-medium">{fromName.split('(')[0]}</span>
                      <span className="text-slate-400 mx-1.5">&rarr;</span>
                      <span className="text-slate-950 dark:text-slate-100 font-bold">{toName.split('(')[0]}</span>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-xs whitespace-nowrap">
                      {m.incidentId ? (
                        <span className="text-sky-700 dark:text-sky-400 font-bold bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800 px-2 py-0.5 rounded">
                          {getRescueLabel(m.incidentId)}
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xs truncate" title={m.notes}>
                      {m.notes || '-'}
                    </td>

                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEdit(m)}
                          className="px-2.5 py-1 text-xs font-bold text-sky-800 hover:text-sky-950 bg-sky-50 hover:bg-sky-100 border border-sky-300 dark:text-sky-300 dark:hover:text-white dark:bg-slate-800 dark:hover:bg-slate-700 dark:border-slate-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-2xs"
                          title="Modifier cette saisie sans l'annuler"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Modifier</span>
                        </button>

                        {isRescueDispatch && (
                          cancelledIncidentIds.has(m.incidentId!) ? (
                            <span className="px-2 py-0.5 text-xs font-bold text-rose-800 bg-rose-100 border border-rose-300 dark:text-rose-300 dark:bg-rose-950/60 dark:border-rose-900 rounded">
                              Annulé
                            </span>
                          ) : (
                            <button
                              onClick={() => setCancellingIncidentId(m.incidentId!)}
                              className="px-2.5 py-1 text-xs font-bold text-rose-800 hover:text-rose-950 bg-rose-50 hover:bg-rose-100 border border-rose-300 dark:text-rose-300 dark:hover:text-white dark:bg-rose-950/60 dark:hover:bg-rose-900 dark:border-rose-800 rounded-lg transition-colors cursor-pointer shadow-2xs"
                              title="Annuler ce secours et réintégrer automatiquement le matériel au poste"
                            >
                              Annuler
                            </button>
                          )
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredMovements.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 italic text-sm">
                    Aucun mouvement ne correspond aux filtres sélectionnés.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Modification d'une saisie dans la Main Courante */}
      {editingMovement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-sky-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col text-slate-900 dark:text-white transition-colors">
            <div className="px-5 py-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-100 dark:bg-sky-500/20 text-sky-700 dark:text-sky-400 flex items-center justify-center">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base">Modifier la saisie de Main Courante</h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400">Corrigez directement sans devoir annuler et ressaisir</p>
                </div>
              </div>
              <button
                onClick={() => setEditingMovement(null)}
                className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-4 text-xs sm:text-sm">
              <div>
                <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Matériel :</label>
                <select
                  value={editEquipmentId}
                  onChange={e => setEditEquipmentId(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
                >
                  {(state.equipments || []).map(eq => (
                    <option key={eq.id} value={eq.id}>
                      {eq.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Quantité :</label>
                <input
                  type="number"
                  min="0"
                  value={editQuantity}
                  onChange={e => setEditQuantity(Math.max(0, parseInt(e.target.value, 10) || 0))}
                  required
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Lieu de départ (Origine) :</label>
                  <select
                    value={editFromLocId}
                    onChange={e => setEditFromLocId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
                  >
                    {state.locations.map(loc => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Lieu d'arrivée (Destination) :</label>
                  <select
                    value={editToLocId}
                    onChange={e => setEditToLocId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
                  >
                    {state.locations.map(loc => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Observations / Détails / Motif :</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  placeholder="Ex: Secours #14, blessé cheville, etc..."
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingMovement(null)}
                  className="px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer min-h-[36px]"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-xs sm:text-sm text-white flex items-center gap-1.5 cursor-pointer shadow-md min-h-[36px]"
                >
                  <Check className="w-4 h-4" />
                  <span>Enregistrer la modification</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Confirmation Annulation de Secours */}
      {cancellingIncidentId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-rose-300 dark:border-red-800 rounded-2xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-900 dark:text-white transition-colors">
            <div className="flex items-center gap-3 text-red-600 dark:text-red-400">
              <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-950 border border-red-300 dark:border-red-700 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 dark:text-white text-base">Annuler ce secours ?</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Cette action réintègre automatiquement tout le matériel déduit au poste de départ.
                </p>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Motif de l'annulation :</label>
              <select
                value={cancelReason}
                onChange={e => setCancelReason(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
              >
                <option value="Fausse alerte / Annulation pisteurs">Fausse alerte / Annulation pisteurs</option>
                <option value="Blessé reparti par ses propres moyens">Blessé reparti par ses propres moyens</option>
                <option value="Erreur de saisie opérateur">Erreur de saisie opérateur</option>
                <option value="Secours pris en charge par un autre service">Secours pris en charge par un autre service</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setCancellingIncidentId(null)}
                className="px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer min-h-[36px]"
              >
                Retour
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 rounded-xl font-bold text-xs sm:text-sm bg-red-600 hover:bg-red-500 text-white shadow-md cursor-pointer min-h-[36px]"
              >
                Confirmer l'annulation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
