import React from 'react';
import { 
  Mountain, 
  PlusCircle, 
  RotateCcw, 
  Clock, 
  Settings, 
  ArrowUpDown,
  FileText,
  HelpCircle,
  Sun,
  Moon
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface HeaderProps {
  activeTab: 'dashboard' | 'closing' | 'history' | 'admin';
  setActiveTab: (tab: 'dashboard' | 'closing' | 'history' | 'admin') => void;
  onOpenNewIncident: () => void;
  onOpenQuickReturn: () => void;
  onOpenInterBaseTransfer: () => void;
  onOpenWelcomeGuide: () => void;
  criticalAlertCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewIncident,
  onOpenQuickReturn,
  onOpenInterBaseTransfer,
  onOpenWelcomeGuide,
  criticalAlertCount,
}) => {
  const { theme, isDark, toggleTheme } = useTheme();

  return (
    <>
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-950/95 border-b border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white shadow-sm backdrop-blur transition-colors">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          {/* Niveau 1 : Marque Alpin & Actions Opérationnelles Prioritaires (Toujours dans la trame) */}
          <div className="flex items-center justify-between h-14 sm:h-16 gap-3">
            {/* Identité Station / Service des Pistes */}
            <div className="flex items-center gap-2.5 sm:gap-3 shrink-0 min-w-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-sky-100 dark:bg-sky-500/10 border border-sky-300 dark:border-sky-400/30 flex items-center justify-center text-sky-600 dark:text-sky-400 shadow-xs shrink-0">
                <Mountain className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 dark:text-white font-sans whitespace-nowrap">
                    PisteMat
                  </span>
                  <span className="text-[10px] font-bold tracking-wider uppercase text-sky-700 bg-sky-100 border border-sky-300 dark:text-sky-300 dark:bg-sky-950/90 dark:border-sky-800/80 rounded px-1.5 py-0.5 whitespace-nowrap">
                    Secours Pistes
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 hidden sm:block truncate">
                  Suivi opérationnel du matériel & déduction automatique
                </p>
              </div>
            </div>

            {/* Actions Opérationnelles Clés : Bien cadrées, immédiatement identifiables et dans la trame */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Bouton commutateur de thème Clair / Sombre */}
              <button
                onClick={toggleTheme}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer text-slate-700 bg-slate-100 hover:bg-slate-200 border-slate-300 dark:text-amber-300 dark:bg-slate-900 dark:hover:bg-slate-800 dark:border-slate-700 shadow-xs min-h-[36px]"
                title={isDark ? "Basculer en Mode Clair (haute lisibilité)" : "Basculer en Mode Sombre"}
                aria-label="Basculer le thème"
              >
                {isDark ? (
                  <>
                    <Sun className="w-4 h-4 text-amber-400 shrink-0" />
                    <span className="hidden sm:inline">Clair</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-4 h-4 text-slate-700 shrink-0" />
                    <span className="hidden sm:inline">Sombre</span>
                  </>
                )}
              </button>

              <button
                onClick={onOpenWelcomeGuide}
                className="md:hidden flex items-center justify-center w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sky-600 dark:text-sky-400 hover:text-sky-800 dark:hover:text-white"
                title="Guide de bienvenue et d'aide"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                onClick={onOpenInterBaseTransfer}
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 dark:text-slate-300 dark:hover:text-white dark:bg-slate-900/90 dark:hover:bg-slate-800 dark:border-slate-700/80 rounded-lg transition-colors cursor-pointer min-h-[36px]"
                title="Faire monter du renfort en matériel vers un poste d'altitude"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
                <span>Renfort Inter-Postes</span>
              </button>

              {/* Bouton Rapatriement - Vert Émeraude Vif & Identifiable */}
              <button
                onClick={onOpenQuickReturn}
                className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 sm:py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 active:scale-95 border border-emerald-400/50 rounded-lg shadow-md shadow-emerald-950/20 dark:shadow-emerald-950/60 transition-all cursor-pointer whitespace-nowrap min-h-[36px]"
                title="Enregistrer le retour de matériel d'un cabinet, hôpital ou signaler une avarie"
              >
                <RotateCcw className="w-4 h-4 text-emerald-100 shrink-0" />
                <span className="hidden xs:inline">Rapatriement</span>
                <span className="xs:hidden">Retour</span>
              </button>

              {/* Bouton Nouveau Secours - Rouge Alerte Opérationnel Prioritaire */}
              <button
                onClick={onOpenNewIncident}
                className="flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs font-black uppercase tracking-wider text-white bg-red-600 hover:bg-red-500 active:scale-95 border border-red-400/60 rounded-lg shadow-lg shadow-red-950/20 dark:shadow-red-950/60 transition-all cursor-pointer whitespace-nowrap min-h-[36px]"
                title="Déclencher un nouveau secours et déduire le matériel en 3 clics"
              >
                <PlusCircle className="w-4 h-4 text-white shrink-0 animate-pulse" />
                <span>Nouveau Secours</span>
              </button>
            </div>
          </div>

          {/* Niveau 2 (Ordinateur & Tablette) : Menu de navigation principal intégré dans la trame */}
          <div className="hidden md:flex items-center justify-between border-t border-slate-200 dark:border-slate-800/80 py-1.5">
            <nav className="flex items-center gap-1.5" aria-label="Menu principal">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer min-h-[34px] ${
                  activeTab === 'dashboard'
                    ? 'bg-sky-100 text-sky-900 border border-sky-300 dark:bg-sky-500/20 dark:text-sky-300 dark:border-sky-500/40 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-white dark:hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Mountain className="w-3.5 h-3.5" />
                <span>Postes & Stocks</span>
                {criticalAlertCount > 0 && (
                  <span className="px-1.5 py-0.2 text-[10px] bg-red-600 text-white rounded font-mono font-bold animate-pulse">
                    {criticalAlertCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('closing')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer min-h-[34px] ${
                  activeTab === 'closing'
                    ? 'bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-500/20 dark:text-amber-300 dark:border-amber-500/40 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-white dark:hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>Fermeture (17h)</span>
              </button>

              <button
                onClick={() => setActiveTab('history')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer min-h-[34px] ${
                  activeTab === 'history'
                    ? 'bg-sky-100 text-sky-900 border border-sky-300 dark:bg-sky-500/20 dark:text-sky-300 dark:border-sky-500/40 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-white dark:hover:bg-slate-900 border border-transparent'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                <span>Main Courante</span>
              </button>

              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer min-h-[34px] ${
                  activeTab === 'admin'
                    ? 'bg-slate-200 text-slate-900 border border-slate-300 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-white dark:hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Settings className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                <span>Administration</span>
              </button>
            </nav>

            <div className="flex items-center gap-2.5">
              <button
                onClick={onOpenWelcomeGuide}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-sky-800 hover:text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-200 dark:text-sky-300 dark:hover:text-white dark:bg-sky-950/80 dark:hover:bg-sky-900/80 dark:border-sky-800/70 rounded-lg transition-colors cursor-pointer shadow-xs"
                title="Consulter le guide de bienvenue et d'utilisation de PisteMat"
              >
                <HelpCircle className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                <span className="font-semibold">Guide d'aide</span>
              </button>

              <div className="text-[11px] text-slate-600 dark:text-slate-400 hidden xl:flex items-center gap-2 font-medium">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Postes opérationnels &bull; Matériel sous contrôle</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Barre de navigation mobile fixée en bas (Thumb Navigation pour Smartphone & Tablette étroite) */}
      <nav 
        aria-label="Navigation mobile" 
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-950/95 border-t border-slate-200 dark:border-slate-800/90 backdrop-blur px-1 sm:px-3 py-1 flex items-center justify-around shadow-2xl safe-area-bottom transition-colors"
      >
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-lg transition-colors cursor-pointer relative min-h-[48px] touch-manipulation ${
            activeTab === 'dashboard' ? 'text-sky-600 dark:text-sky-400 font-bold' : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Mountain className="w-5 h-5" />
            {criticalAlertCount > 0 && (
              <span className="absolute -top-1.5 -right-2 px-1 py-0.2 text-[9px] bg-red-600 text-white rounded-full font-mono font-bold animate-pulse">
                {criticalAlertCount}
              </span>
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] mt-0.5 whitespace-nowrap">Postes</span>
        </button>

        <button
          onClick={() => setActiveTab('closing')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-lg transition-colors cursor-pointer min-h-[48px] touch-manipulation ${
            activeTab === 'closing' ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] sm:text-[11px] mt-0.5 whitespace-nowrap">Fermeture</span>
        </button>

        <button
          onClick={onOpenQuickReturn}
          className="flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-lg text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors cursor-pointer min-h-[48px] touch-manipulation font-semibold"
          title="Retour rapide de matériel"
        >
          <RotateCcw className="w-5 h-5" />
          <span className="text-[10px] sm:text-[11px] mt-0.5 whitespace-nowrap">Rapatrier</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-lg transition-colors cursor-pointer min-h-[48px] touch-manipulation ${
            activeTab === 'history' ? 'text-sky-600 dark:text-sky-400 font-bold' : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span className="text-[10px] sm:text-[11px] mt-0.5 whitespace-nowrap">Journal</span>
        </button>

        <button
          onClick={() => setActiveTab('admin')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-lg transition-colors cursor-pointer min-h-[48px] touch-manipulation ${
            activeTab === 'admin' ? 'text-sky-600 dark:text-sky-400 font-bold' : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] sm:text-[11px] mt-0.5 whitespace-nowrap">Gestion</span>
        </button>
      </nav>
    </>
  );
};
