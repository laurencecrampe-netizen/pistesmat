import React, { useState, useEffect } from 'react';
import { 
  X, 
  Activity, 
  Plus, 
  Minus, 
  Check, 
  AlertTriangle, 
  FileCheck2,
  Edit3,
  MapPin,
  Building2,
  Hospital
} from 'lucide-react';
import { AppState, EquipmentQuantity, RescueIncident, MovementLog, Location } from '../types';

interface NewIncidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onSaveIncident: (
    incident: RescueIncident, 
    movements: MovementLog[], 
    updatedStocks: Record<string, Record<string, number>>,
    newLocations?: Location[]
  ) => void;
}

export const NewIncidentModal: React.FC<NewIncidentModalProps> = ({
  isOpen,
  onClose,
  state,
  onSaveIncident,
}) => {
  const internalBases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
  const externalDestinations = state.locations.filter(l => !(l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);

  // Form states
  const [selectedBaseId, setSelectedBaseId] = useState<string>('');
  const [isCustomBase, setIsCustomBase] = useState<boolean>(false);
  const [customBaseName, setCustomBaseName] = useState<string>('');

  const [selectedInjuryKey, setSelectedInjuryKey] = useState<string>('');
  
  const [destinationId, setDestinationId] = useState<string>('');
  const [isCustomDestination, setIsCustomDestination] = useState<boolean>(false);
  const [customDestinationName, setCustomDestinationName] = useState<string>('');

  const [stayedOnStation, setStayedOnStation] = useState<boolean>(false);
  const [customEquipments, setCustomEquipments] = useState<EquipmentQuantity[]>([]);
  const [victimRef, setVictimRef] = useState<string>('');

  // Reset form cleanly when opening modal
  useEffect(() => {
    if (isOpen) {
      const bases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
      const dests = state.locations.filter(l => !(l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);

      const defaultBase = bases[0]?.id || state.locations[0]?.id || '';
      setSelectedBaseId(defaultBase);
      setIsCustomBase(false);
      setCustomBaseName('');

      const defaultRule = state.deductionRules[0];
      const defaultKey = defaultRule?.injuryKey || 'sans_materiel';
      setSelectedInjuryKey(defaultKey);
      setCustomEquipments(defaultRule ? defaultRule.defaultEquipments.map(e => ({ ...e })) : []);

      const defaultDest = dests[0]?.id || state.locations.find(l => !l.isInternalBase)?.id || state.locations[0]?.id || '';
      setDestinationId(defaultDest);
      setIsCustomDestination(false);
      setCustomDestinationName('');

      setStayedOnStation(false);
      setVictimRef('');
    }
  }, [isOpen, state.locations, state.deductionRules]);

  if (!isOpen) return null;

  // When changing rule, auto-update the suggested equipment
  const handleSelectRule = (injuryKey: string) => {
    setSelectedInjuryKey(injuryKey);
    const rule = state.deductionRules.find(r => r.injuryKey === injuryKey);
    if (rule) {
      setCustomEquipments(rule.defaultEquipments.map(e => ({ ...e })));
    } else {
      setCustomEquipments([]);
    }
  };

  const handleAdjustQuantity = (equipmentId: string, delta: number) => {
    setCustomEquipments(prev => {
      const existing = prev.find(e => e.equipmentId === equipmentId);
      if (existing) {
        const newQty = Math.max(0, existing.quantity + delta);
        if (newQty === 0) {
          return prev.filter(e => e.equipmentId !== equipmentId);
        }
        return prev.map(e => e.equipmentId === equipmentId ? { ...e, quantity: newQty } : e);
      } else if (delta > 0) {
        return [...prev, { equipmentId, quantity: delta }];
      }
      return prev;
    });
  };

  const handleAddEquipment = (equipmentId: string) => {
    handleAdjustQuantity(equipmentId, 1);
  };

  const selectedRule = state.deductionRules.find(r => r.injuryKey === selectedInjuryKey);

  // Stock deficit calculations - ONLY triggers when there is a REAL shortage
  const warnings: string[] = [];
  if (!stayedOnStation && !isCustomBase && selectedBaseId) {
    const baseStocks = state.stocks?.[selectedBaseId];
    if (baseStocks !== undefined) {
      customEquipments.forEach(item => {
        if (item.quantity > 0) {
          const currentQty = baseStocks[item.equipmentId] ?? 0;
          if (currentQty < item.quantity) {
            const eq = state.equipments.find(e => e.id === item.equipmentId);
            warnings.push(
              `${eq?.name?.split('(')[0] || item.equipmentId} : stock disponible (${currentQty}) insuffisant pour déduire ${item.quantity} pièce(s) (passera à ${currentQty - item.quantity})`
            );
          }
        }
      });
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Determine effective Base
    let effectiveBaseId = selectedBaseId;
    let newLocationsToCreate: Location[] = [];

    if (isCustomBase) {
      if (!customBaseName.trim()) return;
      const existing = state.locations.find(
        l => l.name.toLowerCase() === customBaseName.trim().toLowerCase()
      );
      if (existing) {
        effectiveBaseId = existing.id;
      } else {
        effectiveBaseId = `loc_patrol_${Date.now()}`;
        const newBaseLoc: Location = {
          id: effectiveBaseId,
          name: customBaseName.trim(),
          type: 'patrol_base',
          isInternalBase: true,
          active: true,
        };
        newLocationsToCreate.push(newBaseLoc);
      }
    }

    if (!effectiveBaseId) return;

    // Determine effective Destination
    let effectiveDestId = destinationId;
    if (stayedOnStation) {
      effectiveDestId = effectiveBaseId;
    } else if (isCustomDestination) {
      if (!customDestinationName.trim()) return;
      const existing = state.locations.find(
        l => l.name.toLowerCase() === customDestinationName.trim().toLowerCase()
      );
      if (existing) {
        effectiveDestId = existing.id;
      } else {
        effectiveDestId = `loc_dest_${Date.now()}`;
        const newDestLoc: Location = {
          id: effectiveDestId,
          name: customDestinationName.trim(),
          type: 'medical_cabinet',
          isInternalBase: false,
          active: true,
        };
        newLocationsToCreate.push(newDestLoc);
      }
    }

    const nextNumber = (state.incidents.length > 0
      ? Math.max(...state.incidents.map(i => i.number || 0))
      : 13) + 1;

    const incidentId = `inc_${Date.now()}`;
    const timestamp = new Date().toISOString();

    const activeEquipments = customEquipments.filter(e => e.quantity > 0);

    const baseNameDisplay = isCustomBase 
      ? customBaseName.trim() 
      : state.locations.find(l => l.id === effectiveBaseId)?.name || 'Poste';

    const destNameDisplay = stayedOnStation
      ? 'Station (échange sur place)'
      : isCustomDestination
        ? customDestinationName.trim()
        : state.locations.find(l => l.id === effectiveDestId)?.name || 'Extérieur';

    const newIncident: RescueIncident = {
      id: incidentId,
      number: nextNumber,
      timestamp,
      patrolBaseId: effectiveBaseId,
      injuryKey: selectedInjuryKey,
      evacuationType: 'direct',
      finalDestinationId: effectiveDestId,
      equipmentsUsed: activeEquipments,
      victimRef: victimRef.trim() || undefined,
      notes: stayedOnStation 
        ? `Matériel resté en station (échange ambulanciers sur place - stock intact) &middot; ${destNameDisplay}`
        : isCustomDestination
          ? `Destination saisie : ${customDestinationName.trim()}`
          : undefined,
    };

    // Calculate updated stocks and movement logs
    const newStocks = JSON.parse(JSON.stringify(state.stocks));
    if (!newStocks[effectiveBaseId]) newStocks[effectiveBaseId] = {};
    if (effectiveDestId && !newStocks[effectiveDestId]) newStocks[effectiveDestId] = {};

    const newMovements: MovementLog[] = [];

    if (stayedOnStation) {
      // Material stayed on station / exchanged on site: NO stock decrement
      if (activeEquipments.length > 0) {
        activeEquipments.forEach(item => {
          newMovements.push({
            id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
            timestamp,
            equipmentId: item.equipmentId,
            quantity: item.quantity,
            fromLocationId: effectiveBaseId,
            toLocationId: effectiveBaseId,
            incidentId,
            type: 'rescue_dispatch',
            notes: `Secours #${nextNumber} : Matériel resté en station (échange direct sur place / stock préservé)`,
          });
        });
      } else {
        // Sans matériel
        newMovements.push({
          id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          timestamp,
          equipmentId: state.equipments[0]?.id || 'divers',
          quantity: 0,
          fromLocationId: effectiveBaseId,
          toLocationId: effectiveBaseId,
          incidentId,
          type: 'rescue_dispatch',
          notes: `Secours #${nextNumber} : Évacuation simple sans matériel requis`,
        });
      }
    } else {
      // Normal evacuation: Deduce from base and allocate to destination
      if (activeEquipments.length > 0) {
        activeEquipments.forEach(item => {
          const currentBaseQty = newStocks[effectiveBaseId]?.[item.equipmentId] ?? 0;
          newStocks[effectiveBaseId][item.equipmentId] = currentBaseQty - item.quantity;

          if (effectiveDestId) {
            const currentDestQty = newStocks[effectiveDestId]?.[item.equipmentId] ?? 0;
            newStocks[effectiveDestId][item.equipmentId] = currentDestQty + item.quantity;
          }

          newMovements.push({
            id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
            timestamp,
            equipmentId: item.equipmentId,
            quantity: item.quantity,
            fromLocationId: effectiveBaseId,
            toLocationId: effectiveDestId,
            incidentId,
            type: 'rescue_dispatch',
            notes: `Déduit secours #${nextNumber} - ${selectedRule?.injuryLabel || selectedInjuryKey}`,
          });
        });
      } else {
        // Sans matériel requis
        newMovements.push({
          id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          timestamp,
          equipmentId: state.equipments[0]?.id || 'divers',
          quantity: 0,
          fromLocationId: effectiveBaseId,
          toLocationId: effectiveDestId,
          incidentId,
          type: 'rescue_dispatch',
          notes: `Secours #${nextNumber} : Évacuation simple (aucun matériel engagé)`,
        });
      }
    }

    onSaveIncident(newIncident, newMovements, newStocks, newLocationsToCreate);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] text-slate-900 dark:text-white transition-colors">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 bg-slate-50 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-sky-100 dark:bg-sky-500/20 border border-sky-300 dark:border-sky-400/40 flex items-center justify-center text-sky-700 dark:text-sky-400 shrink-0">
              <Activity className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight truncate">
                Nouveau Secours &middot; Saisie Rapide Radio
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 truncate">
                Enregistrement éclair en 3 clics avec déduction automatique
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors p-1 shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 sm:space-y-5 overflow-y-auto flex-1 overscroll-contain">
          {/* Étape 1 : Lieu de départ du matériel (Menu déroulant pour tous les postes de secours) */}
          <div className="space-y-2">
            <label className="text-xs sm:text-sm font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold shrink-0">1</span>
              <span>Lieu de départ du matériel (Poste de secours intervenant)</span>
            </label>

            <select
              value={isCustomBase ? '__custom__' : selectedBaseId}
              onChange={e => {
                if (e.target.value === '__custom__') {
                  setIsCustomBase(true);
                  setSelectedBaseId('');
                } else {
                  setIsCustomBase(false);
                  setSelectedBaseId(e.target.value);
                }
              }}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[42px] cursor-pointer shadow-inner"
            >
              {internalBases.map(base => (
                <option key={base.id} value={base.id}>
                  {base.name} {base.altitude ? `(${base.altitude}m)` : ''} {base.contact ? `— ${base.contact}` : ''}
                </option>
              ))}
              <option value="__custom__">Autre poste / Saisie libre (Patrouilleur, Secteur spécifique...)...</option>
            </select>

            {isCustomBase && (
              <div className="p-3.5 bg-sky-50 dark:bg-slate-950/90 border border-sky-300 dark:border-sky-800/80 rounded-xl space-y-2 mt-2">
                <label className="text-xs sm:text-sm font-bold text-sky-950 dark:text-sky-300 block">
                  Nom du poste ou de la patrouille intervenante (saisie libre) :
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-sky-600 dark:text-sky-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={customBaseName}
                    onChange={e => setCustomBaseName(e.target.value)}
                    placeholder="Ex: Patrouille Snowpark, Secteur Combe Nord, Poste 2400m..."
                    required={isCustomBase}
                    autoFocus
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
                  />
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Permet d'affecter le secours à un poste temporaire, patrouilleur spécifique ou secteur radio.
                </p>
              </div>
            )}
          </div>

          {/* Étape 2 : Type de Traumatisme (avec option Sans Matériel) */}
          <div className="space-y-2">
            <label className="text-xs sm:text-sm font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold shrink-0">2</span>
              <span>Lésion constatée (Déduction automatique)</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {state.deductionRules.map(rule => {
                const isSelected = selectedInjuryKey === rule.injuryKey;
                return (
                  <button
                    key={rule.id}
                    type="button"
                    onClick={() => handleSelectRule(rule.injuryKey)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-sky-600 border-sky-500 text-white shadow-md ring-2 ring-sky-400/50'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="font-bold text-xs sm:text-sm leading-snug">{rule.injuryLabel}</span>
                      {isSelected && <Check className="w-4 h-4 text-white shrink-0 ml-1" />}
                    </div>
                    <span className={`text-xs mt-1.5 ${isSelected ? 'text-sky-100' : 'text-slate-600 dark:text-slate-400'}`}>
                      {rule.defaultEquipments.length === 0
                        ? '0 matériel requis'
                        : rule.defaultEquipments
                            .map(eq => {
                              const e = state.equipments.find(item => item.id === eq.equipmentId);
                              return `${eq.quantity}x ${e?.name.split('(')[0] || eq.equipmentId}`;
                            })
                            .join(', ')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aperçu & Ajustement Dynamique du Matériel Déduit */}
          <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-300 dark:border-slate-800 rounded-xl p-3.5 sm:p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <span className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                <span>Matériel engagé pour ce secours :</span>
              </span>
              <span className="text-xs text-slate-600 dark:text-slate-400">
                Ajustable au besoin (+ / -)
              </span>
            </div>

            {customEquipments.length === 0 ? (
              <div className="text-xs sm:text-sm text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/60 rounded-xl p-3 italic">
                Aucun équipement d'immobilisation n'est requis pour cette intervention (évacuation simple).
              </div>
            ) : (
              <div className="space-y-2">
                {customEquipments.map(item => {
                  const eq = state.equipments.find(e => e.id === item.equipmentId);
                  const availableAtBase = !isCustomBase && selectedBaseId && state.stocks?.[selectedBaseId]
                    ? (state.stocks[selectedBaseId][item.equipmentId] ?? 0)
                    : undefined;

                  return (
                    <div
                      key={item.equipmentId}
                      className="flex items-center justify-between bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm gap-2 shadow-2xs"
                    >
                      <div className="min-w-0">
                        <span className="font-bold text-slate-900 dark:text-white block truncate">{eq?.name || item.equipmentId}</span>
                        {availableAtBase !== undefined && (
                          <span className="text-xs text-slate-600 dark:text-slate-400">
                            (Dispo au poste : <strong className="font-mono text-slate-900 dark:text-slate-200">{availableAtBase}</strong>)
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleAdjustQuantity(item.equipmentId, -1)}
                          className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 flex items-center justify-center text-slate-800 dark:text-slate-200 touch-manipulation cursor-pointer"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="font-mono font-black text-sky-800 dark:text-sky-300 w-6 text-center text-sm tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleAdjustQuantity(item.equipmentId, 1)}
                          className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 flex items-center justify-center text-slate-800 dark:text-slate-200 touch-manipulation cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Ajouter un équipement supplémentaire non prévu */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-1.5">
              <span className="text-xs text-slate-600 dark:text-slate-400 font-semibold mr-1">Ajouter matériel :</span>
              {state.equipments
                .filter(eq => !customEquipments.some(ce => ce.equipmentId === eq.id))
                .slice(0, 4)
                .map(eq => (
                  <button
                    key={eq.id}
                    type="button"
                    onClick={() => handleAddEquipment(eq.id)}
                    className="text-xs px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-300 border border-slate-300 dark:border-slate-700 flex items-center gap-1 min-h-[32px] touch-manipulation cursor-pointer font-semibold shadow-2xs"
                  >
                    <Plus className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
                    <span>{eq.name.split('(')[0]}</span>
                  </button>
                ))}
            </div>
          </div>

          {/* Étape 3 : Lieu d'arrivée du matériel (Menu déroulant pour cabinet médical, hôpital, etc) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs sm:text-sm font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold shrink-0">3</span>
                <span>Lieu d'arrivée du matériel (Destination de l'évacuation)</span>
              </label>
            </div>

            {/* Option Troc / Échange direct */}
            <label className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/60 cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-950/60 transition-colors shadow-2xs">
              <input
                type="checkbox"
                checked={stayedOnStation}
                onChange={e => setStayedOnStation(e.target.checked)}
                className="mt-0.5 rounded border-amber-500 text-amber-600 focus:ring-amber-500 bg-white dark:bg-slate-900 w-4 h-4 cursor-pointer"
              />
              <div className="text-xs sm:text-sm">
                <span className="font-extrabold text-amber-950 dark:text-amber-200 block">
                  Matériel resté en station (Échange direct sur place avec ambulanciers / Aucun matériel emporté)
                </span>
                <span className="text-amber-900 dark:text-amber-300/80 text-xs block mt-0.5 leading-relaxed">
                  Cochez cette case si les pompiers ou ambulanciers ont laissé un matériel en remplacement ou si le blessé a été transféré au pied des pistes sans emporter le matériel du service. <strong>Votre stock reste intact.</strong>
                </span>
              </div>
            </label>

            {!stayedOnStation && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Choisir le lieu d'arrivée (Menu déroulant des destinations) :
                </label>
                <select
                  value={isCustomDestination ? '__custom__' : destinationId}
                  onChange={e => {
                    if (e.target.value === '__custom__') {
                      setIsCustomDestination(true);
                      setDestinationId('');
                    } else {
                      setIsCustomDestination(false);
                      setDestinationId(e.target.value);
                    }
                  }}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[42px] cursor-pointer shadow-inner"
                >
                  {externalDestinations.map(dest => (
                    <option key={dest.id} value={dest.id}>
                      {dest.name} {dest.contact ? `— ${dest.contact}` : ''} {dest.type === 'hospital' ? '[Hôpital / CHU]' : dest.type === 'medical_cabinet' ? '[Cabinet Médical]' : '[Partenaire]'}
                    </option>
                  ))}
                  <option value="__custom__">Autre destination / Saisie libre (Ambulance privée, Hélicoptère, Clinique...)...</option>
                </select>

                {isCustomDestination && (
                  <div className="p-3.5 bg-sky-50 dark:bg-slate-950/90 border border-sky-300 dark:border-sky-800/80 rounded-xl space-y-2 mt-2">
                    <label className="text-xs sm:text-sm font-bold text-sky-950 dark:text-sky-300 block">
                      Nom du lieu ou véhicule d'arrivée (saisie libre) :
                    </label>
                    <div className="relative">
                      <Hospital className="w-4 h-4 text-sky-600 dark:text-sky-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={customDestinationName}
                        onChange={e => setCustomDestinationName(e.target.value)}
                        placeholder="Ex: Ambulance Mont-Blanc, Hélico Dragon 74, Cabinet Dr Martin, Clinique..."
                        required={isCustomDestination}
                        autoFocus
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
                      />
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Renseignez librement le nom du véhicule de secours, de l'hélicoptère, du médecin ou de la clinique.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* VRAI Avertissement de stock négatif (N'apparaît QUE si stock réel insuffisant) */}
          {warnings.length > 0 && (
            <div className="p-3.5 bg-rose-50 dark:bg-red-950/60 border border-rose-300 dark:border-red-700 rounded-xl text-xs sm:text-sm text-rose-950 dark:text-red-200 flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-red-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-extrabold text-rose-950 dark:text-white">Avertissement de stock négatif :</p>
                <ul className="list-disc list-inside mt-1 space-y-0.5 text-rose-900 dark:text-red-300 text-xs">
                  {warnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
                <p className="text-xs text-rose-800 dark:text-red-300/80 mt-1.5 italic">
                  L'enregistrement n'est pas bloqué pour respecter l'urgence du secours, mais pensez à vérifier si un retour précédent n'a pas été oublié.
                </p>
              </div>
            </div>
          )}
        </form>

        {/* Footer Actions */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 bg-slate-50 dark:bg-slate-950/90 border-t border-slate-200 dark:border-slate-800 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-between gap-2.5 sm:gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors text-center min-h-[38px] cursor-pointer"
          >
            Annuler
          </button>

          <button
            onClick={handleSubmit}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-sky-600 hover:bg-sky-500 shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer min-h-[44px]"
          >
            <Check className="w-4 h-4 shrink-0" />
            <span>Valider le Secours & Déduire</span>
          </button>
        </div>
      </div>
    </div>
  );
};
