import React, { useState } from 'react';
import { 
  Settings, 
  Mountain, 
  Layers, 
  Activity, 
  Database, 
  Plus, 
  Download, 
  Upload, 
  AlertTriangle,
  Sliders,
  CheckCircle2,
  Edit2,
  Trash2,
  Check,
  X,
  Minus
} from 'lucide-react';
import { AppState, Equipment, Location, DeductionRule, EquipmentCategory, LocationType } from '../types';
import { exportFullJSONBackup } from '../lib/storage';
import { getInitialAppState } from '../lib/defaultData';

interface AdminViewProps {
  state: AppState;
  onUpdateState: (newState: AppState) => void;
  onAuditStock: (locationId: string, equipmentId: string, newQuantity: number, reason: string) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  state,
  onUpdateState,
  onAuditStock,
}) => {
  const [adminTab, setAdminTab] = useState<'audit' | 'locations' | 'equipments' | 'rules' | 'backup'>('audit');

  // Morning audit state
  const [selectedAuditLocationId, setSelectedAuditLocationId] = useState<string>(state.locations[0]?.id || '');
  const [auditReason, setAuditReason] = useState<string>('Contrôle visuel lors du briefing du matin');
  const [auditSuccessMsg, setAuditSuccessMsg] = useState<string | null>(null);

  // Locations management
  const [isAddingLocation, setIsAddingLocation] = useState<boolean>(false);
  const [newLocName, setNewLocName] = useState<string>('');
  const [newLocType, setNewLocType] = useState<LocationType>('patrol_base');
  const [newLocAltitude, setNewLocAltitude] = useState<number>(2000);
  const [newLocContact, setNewLocContact] = useState<string>('');
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);

  // Equipments management
  const [isAddingEquipment, setIsAddingEquipment] = useState<boolean>(false);
  const [newEqName, setNewEqName] = useState<string>('');
  const [newEqCategory, setNewEqCategory] = useState<EquipmentCategory>('immobilisation');
  const [newEqThreshold, setNewEqThreshold] = useState<number>(2);
  const [editingEquipment, setEditingEquipment] = useState<Equipment | null>(null);

  // Deduction Rules management
  const [isAddingRule, setIsAddingRule] = useState<boolean>(false);
  const [newRuleLabel, setNewRuleLabel] = useState<string>('');
  const [newRuleKey, setNewRuleKey] = useState<string>('');
  const [newRuleDesc, setNewRuleDesc] = useState<string>('');
  const [editingRule, setEditingRule] = useState<DeductionRule | null>(null);

  // Backup restore
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [restoreSuccessMsg, setRestoreSuccessMsg] = useState<string | null>(null);

  // In-app confirmation dialog (replaces native window.confirm)
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const handleApplyAudit = (eqId: string, newQty: number) => {
    if (!selectedAuditLocationId) return;
    onAuditStock(selectedAuditLocationId, eqId, newQty, auditReason);
    setAuditSuccessMsg(`Stock mis à jour pour ${state.equipments.find(e => e.id === eqId)?.name.split('(')[0]}`);
    setTimeout(() => setAuditSuccessMsg(null), 3000);
  };

  // --- LOCATION ACTIONS ---
  const handleAddLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocName.trim()) return;

    const newLoc: Location = {
      id: `loc_${Date.now()}`,
      name: newLocName.trim(),
      type: newLocType,
      isInternalBase: newLocType === 'patrol_base',
      altitude: newLocType === 'patrol_base' ? newLocAltitude : undefined,
      contact: newLocContact.trim() || undefined,
      active: true,
    };

    const updatedState = { ...state, locations: [...state.locations, newLoc] };
    if (!updatedState.stocks[newLoc.id]) {
      updatedState.stocks[newLoc.id] = {};
      state.equipments.forEach(eq => {
        updatedState.stocks[newLoc.id][eq.id] = 0;
      });
    }

    if (!updatedState.minThresholds[newLoc.id]) {
      updatedState.minThresholds[newLoc.id] = {};
      state.equipments.forEach(eq => {
        updatedState.minThresholds[newLoc.id][eq.id] = eq.defaultMinThreshold;
      });
    }

    onUpdateState(updatedState);
    setIsAddingLocation(false);
    setNewLocName('');
    setNewLocContact('');
  };

  const handleUpdateLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLocation || !editingLocation.name.trim()) return;

    const isBase = editingLocation.type === 'patrol_base';
    const updatedLoc: Location = {
      ...editingLocation,
      isInternalBase: isBase,
      altitude: isBase ? editingLocation.altitude : undefined,
    };

    const updatedLocations = state.locations.map(loc => 
      loc.id === updatedLoc.id ? updatedLoc : loc
    );

    onUpdateState({ ...state, locations: updatedLocations });
    setEditingLocation(null);
  };

  const handleDeleteLocation = (locId: string) => {
    const loc = state.locations.find(l => l.id === locId);
    setConfirmDialog({
      title: 'Supprimer ce lieu',
      message: `Êtes-vous sûr de vouloir supprimer définitivement "${loc?.name || locId}" ?`,
      onConfirm: () => {
        const updatedLocations = state.locations.filter(l => l.id !== locId);
        onUpdateState({ ...state, locations: updatedLocations });
        if (editingLocation?.id === locId) setEditingLocation(null);
      },
    });
  };

  // --- EQUIPMENT ACTIONS ---
  const handleAddEquipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEqName.trim()) return;

    const newEq: Equipment = {
      id: `eq_${Date.now()}`,
      name: newEqName.trim(),
      category: newEqCategory,
      unit: 'pièce',
      defaultMinThreshold: newEqThreshold,
      active: true,
    };

    const updatedState = { ...state, equipments: [...state.equipments, newEq] };
    Object.keys(updatedState.stocks).forEach(locId => {
      if (!updatedState.stocks[locId]) updatedState.stocks[locId] = {};
      updatedState.stocks[locId][newEq.id] = 0;
    });

    onUpdateState(updatedState);
    setIsAddingEquipment(false);
    setNewEqName('');
  };

  const handleUpdateEquipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEquipment || !editingEquipment.name.trim()) return;

    const updatedEquipments = state.equipments.map(eq => 
      eq.id === editingEquipment.id ? editingEquipment : eq
    );

    onUpdateState({ ...state, equipments: updatedEquipments });
    setEditingEquipment(null);
  };

  const handleDeleteEquipment = (eqId: string) => {
    const eq = state.equipments.find(e => e.id === eqId);
    setConfirmDialog({
      title: 'Supprimer ce matériel',
      message: `Êtes-vous sûr de vouloir supprimer "${eq?.name || eqId}" du catalogue ? Il sera également retiré des règles de déduction associées.`,
      onConfirm: () => {
        const updatedEquipments = state.equipments.filter(e => e.id !== eqId);
        const updatedRules = state.deductionRules.map(r => ({
          ...r,
          defaultEquipments: r.defaultEquipments.filter(de => de.equipmentId !== eqId),
        }));
        onUpdateState({
          ...state,
          equipments: updatedEquipments,
          deductionRules: updatedRules,
        });
        if (editingEquipment?.id === eqId) setEditingEquipment(null);
      },
    });
  };

  // --- DEDUCTION RULES ACTIONS ---
  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleLabel.trim()) return;

    const key = newRuleKey.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_') || `rule_${Date.now()}`;
    const newRule: DeductionRule = {
      id: `rule_${Date.now()}`,
      injuryKey: key,
      injuryLabel: newRuleLabel.trim(),
      description: newRuleDesc.trim() || 'Règle personnalisée',
      defaultEquipments: [],
    };

    onUpdateState({ ...state, deductionRules: [...state.deductionRules, newRule] });
    setIsAddingRule(false);
    setNewRuleLabel('');
    setNewRuleKey('');
    setNewRuleDesc('');
  };

  const handleUpdateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRule || !editingRule.injuryLabel.trim()) return;

    const updatedRules = state.deductionRules.map(r => 
      r.id === editingRule.id ? editingRule : r
    );

    onUpdateState({ ...state, deductionRules: updatedRules });
    setEditingRule(null);
  };

  const handleDeleteRule = (ruleId: string) => {
    const rule = state.deductionRules.find(r => r.id === ruleId);
    setConfirmDialog({
      title: 'Supprimer cette règle',
      message: `Êtes-vous sûr de vouloir supprimer la règle de déduction "${rule?.injuryLabel || ruleId}" ?`,
      onConfirm: () => {
        const updatedRules = state.deductionRules.filter(r => r.id !== ruleId);
        onUpdateState({ ...state, deductionRules: updatedRules });
        if (editingRule?.id === ruleId) setEditingRule(null);
      },
    });
  };

  const handleAdjustRuleEquipment = (equipmentId: string, delta: number) => {
    if (!editingRule) return;
    const existing = editingRule.defaultEquipments.find(e => e.equipmentId === equipmentId);
    let newItems = [...editingRule.defaultEquipments];

    if (existing) {
      const newQty = existing.quantity + delta;
      if (newQty <= 0) {
        newItems = newItems.filter(e => e.equipmentId !== equipmentId);
      } else {
        newItems = newItems.map(e => e.equipmentId === equipmentId ? { ...e, quantity: newQty } : e);
      }
    } else if (delta > 0) {
      newItems.push({ equipmentId, quantity: delta });
    }

    setEditingRule({ ...editingRule, defaultEquipments: newItems });
  };

  const handleRestoreJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRestoreError(null);
    setRestoreSuccessMsg(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.locations && parsed.equipments && parsed.stocks) {
          onUpdateState(parsed);
          setRestoreSuccessMsg('Sauvegarde restaurée avec succès ! Les données ont été chargées.');
          setTimeout(() => setRestoreSuccessMsg(null), 5000);
        } else {
          setRestoreError('Format de fichier de sauvegarde invalide (structure JSON non reconnue).');
        }
      } catch (err: any) {
        setRestoreError('Impossible de lire le fichier JSON : ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  const handleResetDefaults = () => {
    setConfirmDialog({
      title: 'Réinitialiser la station aux valeurs types',
      message: 'Êtes-vous sûr de vouloir réinitialiser toutes les données aux valeurs par défaut de station modèle ? Cette action effacera les saisies et mouvements actuels.',
      onConfirm: () => {
        const initial = getInitialAppState();
        onUpdateState(initial);
      },
    });
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Header Admin */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <Settings className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>Administration des Données & Tables</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Créez et modifiez librement tous vos lieux, matériels et règles d'intervention
          </p>
        </div>

        <button
          onClick={() => exportFullJSONBackup(state)}
          className="self-start sm:self-auto px-4 py-2 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer min-h-[38px] shadow-2xs"
        >
          <Download className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
          <span>Sauvegarde JSON</span>
        </button>
      </div>

      {/* Tabs navigation Admin */}
      <div className="flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-950/80 border border-slate-300 dark:border-slate-800 rounded-xl overflow-x-auto text-xs sm:text-sm shadow-2xs transition-colors">
        <button
          onClick={() => setAdminTab('audit')}
          className={`px-3.5 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer min-h-[38px] ${
            adminTab === 'audit' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-700 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Recalibrage Stocks</span>
        </button>
        <button
          onClick={() => setAdminTab('locations')}
          className={`px-3.5 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer min-h-[38px] ${
            adminTab === 'locations' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-700 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Mountain className="w-4 h-4" />
          <span>Lieux & Postes ({state.locations.length})</span>
        </button>
        <button
          onClick={() => setAdminTab('equipments')}
          className={`px-3.5 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer min-h-[38px] ${
            adminTab === 'equipments' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-700 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Matériels ({state.equipments.length})</span>
        </button>
        <button
          onClick={() => setAdminTab('rules')}
          className={`px-3.5 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer min-h-[38px] ${
            adminTab === 'rules' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-700 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Règles de Déduction ({state.deductionRules.length})</span>
        </button>
        <button
          onClick={() => setAdminTab('backup')}
          className={`px-3.5 py-2 rounded-lg font-bold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer min-h-[38px] ${
            adminTab === 'backup' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-700 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Sauvegarde / Reset</span>
        </button>
      </div>

      {/* Tab 1 : Recalibrage Stocks */}
      {adminTab === 'audit' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl space-y-5 sm:space-y-6 text-slate-900 dark:text-white transition-colors">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
              Recalibrage & Inventaire Physique
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Ajustez les quantités pour correspondre à l'inventaire physique réel du matin
            </p>
          </div>

          {auditSuccessMsg && (
            <div className="p-3 bg-emerald-100 border border-emerald-300 dark:bg-emerald-950/80 dark:border-emerald-700 rounded-xl text-xs sm:text-sm text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{auditSuccessMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Sélectionner le lieu à auditer :</label>
              <select
                value={selectedAuditLocationId}
                onChange={e => setSelectedAuditLocationId(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px] cursor-pointer"
              >
                {state.locations.map(loc => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} {loc.isInternalBase ? '(Poste interne)' : '(Lieu externe)'}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Motif de l'ajustement :</label>
              <input
                type="text"
                value={auditReason}
                onChange={e => setAuditReason(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[38px]"
              />
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300">Stocks enregistrés au lieu :</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {(state.equipments || []).map(eq => {
                const current = state.stocks?.[selectedAuditLocationId]?.[eq.id] ?? 0;
                return (
                  <div key={eq.id} className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                    <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">{eq.name.split('(')[0]}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <input
                        type="number"
                        min="0"
                        defaultValue={current}
                        key={`${selectedAuditLocationId}-${eq.id}-${current}`}
                        onBlur={e => {
                          const val = parseInt(e.target.value, 10);
                          if (!isNaN(val) && val !== current) {
                            handleApplyAudit(eq.id, val);
                          }
                        }}
                        className="w-16 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 text-center font-mono font-bold text-xs sm:text-sm text-slate-900 dark:text-white focus:border-sky-500"
                      />
                      <span className="text-xs text-slate-500 dark:text-slate-400">unités</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2 : Table des Lieux */}
      {adminTab === 'locations' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl space-y-5 sm:space-y-6 text-slate-900 dark:text-white transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">Table des Lieux & Postes</h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">Ajoutez, modifiez le nom, l'altitude, les contacts radio et l'état des lieux</p>
            </div>
            <button
              onClick={() => {
                setIsAddingLocation(!isAddingLocation);
                setEditingLocation(null);
              }}
              className="self-start sm:self-auto px-4 py-2 rounded-xl font-bold text-xs sm:text-sm bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center gap-1.5 cursor-pointer min-h-[38px] shadow-sm"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Nouveau Lieu</span>
            </button>
          </div>

          {/* Form Ajout Lieu */}
          {isAddingLocation && (
            <form onSubmit={handleAddLocation} className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl space-y-3 text-xs sm:text-sm shadow-sm">
              <h4 className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>Créer un nouveau lieu :</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Nom du lieu :</label>
                  <input
                    type="text"
                    value={newLocName}
                    onChange={e => setNewLocName(e.target.value)}
                    placeholder="Ex: Poste Combe Nord, SAMU 74, Ambulance..."
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Type de lieu :</label>
                  <select
                    value={newLocType}
                    onChange={e => setNewLocType(e.target.value as any)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px] cursor-pointer"
                  >
                    <option value="patrol_base">Poste de secours (Interne pistes)</option>
                    <option value="medical_cabinet">Cabinet médical station (Lieu d'évacuation)</option>
                    <option value="hospital">Hôpital / Urgences / CHU (Lieu d'évacuation)</option>
                    <option value="maintenance">Atelier / Maintenance révision</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Altitude (mètres) :</label>
                  <input
                    type="number"
                    value={newLocAltitude}
                    onChange={e => setNewLocAltitude(parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Contact / Canal radio :</label>
                  <input
                    type="text"
                    value={newLocContact}
                    onChange={e => setNewLocContact(e.target.value)}
                    placeholder="Ex: Canal 2 / Poste 405..."
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingLocation(false)}
                  className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white min-h-[36px] cursor-pointer shadow-sm"
                >
                  Enregistrer le lieu
                </button>
              </div>
            </form>
          )}

          {/* Form Edition Lieu */}
          {editingLocation && (
            <form onSubmit={handleUpdateLocation} className="p-4 sm:p-5 bg-sky-50 dark:bg-sky-950/40 border border-sky-300 dark:border-sky-700 rounded-xl space-y-3 text-xs sm:text-sm shadow-sm">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sky-950 dark:text-sky-300 flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                  <span>Modifier le lieu : {editingLocation.name}</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setEditingLocation(null)}
                  className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Nom du lieu :</label>
                  <input
                    type="text"
                    value={editingLocation.name}
                    onChange={e => setEditingLocation({ ...editingLocation, name: e.target.value })}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Type de lieu :</label>
                  <select
                    value={editingLocation.type}
                    onChange={e => setEditingLocation({ ...editingLocation, type: e.target.value as any })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px] cursor-pointer"
                  >
                    <option value="patrol_base">Poste de secours (Interne pistes)</option>
                    <option value="medical_cabinet">Cabinet médical station (Lieu d'évacuation)</option>
                    <option value="hospital">Hôpital / Urgences / CHU (Lieu d'évacuation)</option>
                    <option value="maintenance">Atelier / Maintenance révision</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Altitude (mètres) :</label>
                  <input
                    type="number"
                    value={editingLocation.altitude || 0}
                    onChange={e => setEditingLocation({ ...editingLocation, altitude: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Contact / Canal radio :</label>
                  <input
                    type="text"
                    value={editingLocation.contact || ''}
                    onChange={e => setEditingLocation({ ...editingLocation, contact: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Statut opérationnel :</label>
                  <select
                    value={editingLocation.active !== false ? 'active' : 'inactive'}
                    onChange={e => setEditingLocation({ ...editingLocation, active: e.target.value === 'active' })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px] cursor-pointer"
                  >
                    <option value="active">Actif (Visible partout)</option>
                    <option value="inactive">Inactif / Désactivé</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => handleDeleteLocation(editingLocation.id)}
                  className="px-3.5 py-1.5 rounded-lg text-rose-800 dark:text-rose-300 hover:text-white hover:bg-rose-600 dark:hover:bg-rose-900 border border-rose-300 dark:border-rose-800 flex items-center gap-1.5 cursor-pointer min-h-[36px] transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Supprimer ce lieu</span>
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingLocation(null)}
                    className="px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white flex items-center gap-1.5 cursor-pointer min-h-[36px] shadow-sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Enregistrer</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Liste Lieux existants */}
          <div className="space-y-2.5">
            {state.locations.map(loc => (
              <div
                key={loc.id}
                className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm shadow-2xs"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900 dark:text-white text-base truncate">{loc.name}</span>
                    {loc.active === false && (
                      <span className="text-xs bg-rose-100 border border-rose-300 text-rose-900 dark:bg-rose-950 dark:border-rose-800 dark:text-rose-300 px-2 py-0.5 rounded-md font-bold">
                        Inactif
                      </span>
                    )}
                  </div>
                  <div className="text-slate-600 dark:text-slate-400 mt-0.5">
                    {loc.isInternalBase ? `Poste de secours (${loc.altitude ? `${loc.altitude}m` : 'Régulation'})` : `Lieu d'évacuation (${loc.type})`}
                    {loc.contact && <span className="text-slate-500 ml-2">&middot; {loc.contact}</span>}
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  <button
                    onClick={() => {
                      setEditingLocation({ ...loc });
                      setIsAddingLocation(false);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-sky-700 dark:text-sky-400 border border-slate-300 dark:border-slate-700 font-bold flex items-center gap-1.5 cursor-pointer min-h-[34px] shadow-2xs transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Modifier</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3 : Table du Matériel */}
      {adminTab === 'equipments' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl space-y-5 sm:space-y-6 text-slate-900 dark:text-white transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">Table du Matériel Suivi</h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">Modifiez les noms, catégories et seuils d'alerte min par défaut</p>
            </div>
            <button
              onClick={() => {
                setIsAddingEquipment(!isAddingEquipment);
                setEditingEquipment(null);
              }}
              className="self-start sm:self-auto px-4 py-2 rounded-xl font-bold text-xs sm:text-sm bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center gap-1.5 cursor-pointer min-h-[38px] shadow-sm"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Nouveau Matériel</span>
            </button>
          </div>

          {/* Form Ajout Matériel */}
          {isAddingEquipment && (
            <form onSubmit={handleAddEquipment} className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl space-y-3 text-xs sm:text-sm shadow-sm">
              <h4 className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>Créer une nouvelle référence :</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Nom du matériel :</label>
                  <input
                    type="text"
                    value={newEqName}
                    onChange={e => setNewEqName(e.target.value)}
                    placeholder="Ex: Attelle de traction Donway..."
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Catégorie :</label>
                  <select
                    value={newEqCategory}
                    onChange={e => setNewEqCategory(e.target.value as any)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px] cursor-pointer"
                  >
                    <option value="immobilisation">Immobilisation globale (MID)</option>
                    <option value="rachis">Rachis / Colliers</option>
                    <option value="membres">Membres / Attelles</option>
                    <option value="divers">Divers / Sauvetage</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Seuil alerte par défaut :</label>
                  <input
                    type="number"
                    min="1"
                    value={newEqThreshold}
                    onChange={e => setNewEqThreshold(parseInt(e.target.value, 10) || 1)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingEquipment(false)}
                  className="px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white min-h-[36px] cursor-pointer shadow-sm"
                >
                  Ajouter au catalogue
                </button>
              </div>
            </form>
          )}

          {/* Form Edition Matériel */}
          {editingEquipment && (
            <form onSubmit={handleUpdateEquipment} className="p-4 sm:p-5 bg-sky-50 dark:bg-sky-950/40 border border-sky-300 dark:border-sky-700 rounded-xl space-y-3 text-xs sm:text-sm shadow-sm">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sky-950 dark:text-sky-300 flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                  <span>Modifier le matériel : {editingEquipment.name}</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setEditingEquipment(null)}
                  className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Nom du matériel :</label>
                  <input
                    type="text"
                    value={editingEquipment.name}
                    onChange={e => setEditingEquipment({ ...editingEquipment, name: e.target.value })}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Catégorie :</label>
                  <select
                    value={editingEquipment.category}
                    onChange={e => setEditingEquipment({ ...editingEquipment, category: e.target.value as any })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px] cursor-pointer"
                  >
                    <option value="immobilisation">Immobilisation globale (MID)</option>
                    <option value="rachis">Rachis / Colliers</option>
                    <option value="membres">Membres / Attelles</option>
                    <option value="divers">Divers / Sauvetage</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Seuil alerte par défaut :</label>
                  <input
                    type="number"
                    min="1"
                    value={editingEquipment.defaultMinThreshold}
                    onChange={e => setEditingEquipment({ ...editingEquipment, defaultMinThreshold: parseInt(e.target.value, 10) || 1 })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => handleDeleteEquipment(editingEquipment.id)}
                  className="px-3.5 py-1.5 rounded-lg text-rose-800 dark:text-rose-300 hover:text-white hover:bg-rose-600 dark:hover:bg-rose-900 border border-rose-300 dark:border-rose-800 flex items-center gap-1.5 cursor-pointer min-h-[36px] transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Supprimer ce matériel</span>
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingEquipment(null)}
                    className="px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white flex items-center gap-1.5 cursor-pointer min-h-[36px] shadow-sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Enregistrer</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Liste Matériel */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {state.equipments.map(eq => (
              <div
                key={eq.id}
                className="p-3.5 sm:p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs sm:text-sm gap-2 shadow-2xs"
              >
                <div className="min-w-0">
                  <span className="font-extrabold text-slate-900 dark:text-white text-sm sm:text-base truncate block">{eq.name}</span>
                  <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                    Catégorie : <span className="font-semibold text-slate-800 dark:text-slate-300">{eq.category}</span> &middot; Seuil min : <strong className="text-amber-700 dark:text-amber-400">{eq.defaultMinThreshold}</strong>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setEditingEquipment({ ...eq });
                    setIsAddingEquipment(false);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-sky-700 dark:text-sky-400 border border-slate-300 dark:border-slate-700 font-bold flex items-center gap-1.5 cursor-pointer min-h-[34px] shrink-0 shadow-2xs transition-colors"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Modifier</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4 : Table des Règles de Déduction */}
      {adminTab === 'rules' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl space-y-5 sm:space-y-6 text-slate-900 dark:text-white transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">Table des Règles de Déduction</h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                Associez pour chaque traumatisme radio les matériels déduits par défaut sans intervention des pisteurs
              </p>
            </div>
            <button
              onClick={() => {
                setIsAddingRule(!isAddingRule);
                setEditingRule(null);
              }}
              className="self-start sm:self-auto px-4 py-2 rounded-xl font-bold text-xs sm:text-sm bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center gap-1.5 cursor-pointer min-h-[38px] shadow-sm"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Nouvelle Règle</span>
            </button>
          </div>

          {/* Form Ajout Règle */}
          {isAddingRule && (
            <form onSubmit={handleAddRule} className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl space-y-3 text-xs sm:text-sm shadow-sm">
              <h4 className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>Créer une nouvelle règle de déduction :</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Libellé du traumatisme :</label>
                  <input
                    type="text"
                    value={newRuleLabel}
                    onChange={e => setNewRuleLabel(e.target.value)}
                    placeholder="Ex: Traumatisme Genou / LCA, Luxation Épaule..."
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Clé interne (identifiant) :</label>
                  <input
                    type="text"
                    value={newRuleKey}
                    onChange={e => setNewRuleKey(e.target.value)}
                    placeholder="Ex: luxation_epaule"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
              </div>
              <div>
                <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Description / Critères d'appel radio :</label>
                <input
                  type="text"
                  value={newRuleDesc}
                  onChange={e => setNewRuleDesc(e.target.value)}
                  placeholder="Ex: Suspicion entorse grave, déformation visible..."
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingRule(false)}
                  className="px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white min-h-[36px] cursor-pointer shadow-sm"
                >
                  Créer la règle
                </button>
              </div>
            </form>
          )}

          {/* Form Edition Règle */}
          {editingRule && (
            <form onSubmit={handleUpdateRule} className="p-4 sm:p-5 bg-sky-50 dark:bg-sky-950/40 border border-sky-300 dark:border-sky-700 rounded-xl space-y-4 text-xs sm:text-sm shadow-sm">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sky-950 dark:text-sky-300 flex items-center gap-2 text-sm sm:text-base">
                  <Edit2 className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                  <span>Modifier la règle : {editingRule.injuryLabel}</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setEditingRule(null)}
                  className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Libellé du traumatisme :</label>
                  <input
                    type="text"
                    value={editingRule.injuryLabel}
                    onChange={e => setEditingRule({ ...editingRule, injuryLabel: e.target.value })}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
                <div>
                  <label className="text-slate-800 dark:text-slate-300 font-bold block mb-1">Description :</label>
                  <input
                    type="text"
                    value={editingRule.description}
                    onChange={e => setEditingRule({ ...editingRule, description: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white min-h-[36px]"
                  />
                </div>
              </div>

              {/* Matériels déduits par cette règle */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-sky-900/60">
                <label className="text-xs sm:text-sm font-extrabold text-sky-950 dark:text-sky-200 block">
                  Matériels déduits automatiquement par cette règle :
                </label>
                <div className="space-y-2">
                  {editingRule.defaultEquipments.map(item => {
                    const eq = state.equipments.find(e => e.id === item.equipmentId);
                    return (
                      <div key={item.equipmentId} className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 gap-2 shadow-2xs">
                        <span className="font-bold text-slate-900 dark:text-white truncate">{eq?.name || item.equipmentId}</span>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleAdjustRuleEquipment(item.equipmentId, -1)}
                            className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center cursor-pointer"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="font-mono font-black text-sky-800 dark:text-sky-300 w-6 text-center tabular-nums">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => handleAdjustRuleEquipment(item.equipmentId, 1)}
                            className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {editingRule.defaultEquipments.length === 0 && (
                    <p className="text-slate-500 italic py-1 text-xs">Aucun matériel configuré pour cette règle.</p>
                  )}
                </div>

                {/* Ajouter un matériel à la règle */}
                <div className="pt-2 flex flex-wrap items-center gap-1.5">
                  <span className="text-xs text-slate-600 dark:text-slate-400 font-semibold mr-1">Ajouter matériel :</span>
                  {state.equipments
                    .filter(eq => !editingRule.defaultEquipments.some(de => de.equipmentId === eq.id))
                    .map(eq => (
                      <button
                        key={eq.id}
                        type="button"
                        onClick={() => handleAdjustRuleEquipment(eq.id, 1)}
                        className="text-xs px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-300 border border-slate-300 dark:border-slate-700 flex items-center gap-1 cursor-pointer min-h-[30px] font-semibold"
                      >
                        <Plus className="w-3 h-3 text-sky-600 dark:text-sky-400" />
                        <span>{eq.name.split('(')[0]}</span>
                      </button>
                    ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => handleDeleteRule(editingRule.id)}
                  className="px-3.5 py-1.5 rounded-lg text-rose-800 dark:text-rose-300 hover:text-white hover:bg-rose-600 dark:hover:bg-rose-900 border border-rose-300 dark:border-rose-800 flex items-center gap-1.5 cursor-pointer min-h-[36px] transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Supprimer la règle</span>
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingRule(null)}
                    className="px-3.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white min-h-[36px] cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold text-white flex items-center gap-1.5 cursor-pointer min-h-[36px] shadow-sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Enregistrer la règle</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Liste des Règles */}
          <div className="space-y-3">
            {state.deductionRules.map(rule => (
              <div
                key={rule.id}
                className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2 text-xs sm:text-sm shadow-2xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900 dark:text-white text-base">{rule.injuryLabel}</span>
                    <span className="text-xs font-mono text-slate-600 dark:text-slate-400 bg-slate-200 dark:bg-slate-900 px-2 py-0.5 rounded font-bold">{rule.injuryKey}</span>
                  </div>
                  <button
                    onClick={() => {
                      setEditingRule({ ...rule, defaultEquipments: rule.defaultEquipments.map(e => ({ ...e })) });
                      setIsAddingRule(false);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-sky-700 dark:text-sky-400 border border-slate-300 dark:border-slate-700 font-bold flex items-center gap-1.5 cursor-pointer min-h-[32px] shadow-2xs transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Modifier</span>
                  </button>
                </div>
                <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm">{rule.description}</p>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-xs text-slate-700 dark:text-slate-300 font-bold mr-1">Matériels déduits :</span>
                  {rule.defaultEquipments.map(e => {
                    const eq = state.equipments.find(item => item.id === e.equipmentId);
                    return (
                      <span
                        key={e.equipmentId}
                        className="px-2.5 py-1 rounded-lg bg-sky-100 text-sky-950 border border-sky-300 dark:bg-sky-950 dark:text-sky-300 dark:border-sky-800 font-mono font-bold text-xs"
                      >
                        {e.quantity}x {eq?.name.split('(')[0] || e.equipmentId}
                      </span>
                    );
                  })}
                  {rule.defaultEquipments.length === 0 && (
                    <span className="text-slate-500 italic text-xs">Aucun matériel</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5 : Sauvegarde & Restauration */}
      {adminTab === 'backup' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm dark:shadow-xl space-y-5 sm:space-y-6 text-slate-900 dark:text-white transition-colors">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">Sauvegarde & Restauration de Saison</h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Téléchargez une copie intégrale de la base ou restaurez vos données sur un nouveau poste
            </p>
          </div>

          {restoreError && (
            <div className="p-3.5 bg-rose-100 border border-rose-300 dark:bg-red-950/80 dark:border-red-700 rounded-xl text-xs sm:text-sm text-rose-900 dark:text-red-200">
              {restoreError}
            </div>
          )}

          {restoreSuccessMsg && (
            <div className="p-3.5 bg-emerald-100 border border-emerald-300 dark:bg-emerald-950/80 dark:border-emerald-700 rounded-xl text-xs sm:text-sm text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{restoreSuccessMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 text-xs sm:text-sm flex flex-col justify-between shadow-2xs">
              <div className="space-y-2">
                <h4 className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Download className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                  <span>Exporter Sauvegarde (JSON)</span>
                </h4>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  Génère un fichier de sauvegarde contenant tous les postes, le matériel, les stocks actuels et l'historique complet des mouvements. Idéal pour clore et archiver la saison d'hiver.
                </p>
              </div>
              <button
                onClick={() => exportFullJSONBackup(state)}
                className="w-full py-2.5 rounded-xl font-bold bg-sky-600 hover:bg-sky-500 text-white shadow-md transition-colors min-h-[42px] cursor-pointer"
              >
                Télécharger .json
              </button>
            </div>

            <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 text-xs sm:text-sm flex flex-col justify-between shadow-2xs">
              <div className="space-y-2">
                <h4 className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Upload className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Restaurer une Sauvegarde</span>
                </h4>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  Importez un fichier de sauvegarde préalablement exporté pour recharger les données sur un autre ordinateur de la régulation.
                </p>
              </div>
              <input
                type="file"
                accept=".json"
                onChange={handleRestoreJSON}
                className="w-full text-xs text-slate-600 dark:text-slate-400 file:mr-2 file:py-2 file:px-3 file:rounded-xl file:border file:border-slate-300 dark:file:border-slate-700 file:text-xs file:font-semibold file:bg-white dark:file:bg-slate-800 file:text-slate-800 dark:file:text-slate-200 hover:file:bg-slate-100 dark:hover:file:bg-slate-700 cursor-pointer min-h-[42px]"
              />
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-rose-50 dark:bg-red-950/30 border border-rose-300 dark:border-red-800/60 rounded-xl space-y-3 text-xs sm:text-sm shadow-2xs">
            <h4 className="font-extrabold text-rose-950 dark:text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-red-400 shrink-0" />
              <span>Zone Danger : Réinitialiser aux valeurs de départ</span>
            </h4>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
              Réinitialise tous les postes, les règles et les stocks aux valeurs types d'une station alpine (Poste Central, Sommet, Combe, Cabinet Médical, Hôpital).
            </p>
            <button
              onClick={handleResetDefaults}
              className="px-4 py-2.5 rounded-xl font-bold bg-rose-600 hover:bg-rose-500 text-white shadow transition-colors min-h-[40px] cursor-pointer"
            >
              Réinitialiser la station aux valeurs types
            </button>
          </div>
        </div>
      )}

      {/* Modale de confirmation in-app non-bloquante */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 text-slate-900 dark:text-white">
            <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-500/20 border border-rose-300 dark:border-rose-400/40 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              </div>
              <h4 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white tracking-tight">
                {confirmDialog.title}
              </h4>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmDialog.message}
            </p>
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer min-h-[38px]"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  confirmDialog.onConfirm();
                  setConfirmDialog(null);
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-xl transition-colors cursor-pointer shadow-md min-h-[38px]"
              >
                Confirmer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
