import React, { useState, useEffect } from 'react';
import { 
  X, 
  RotateCcw, 
  Check, 
  Wrench, 
  Mountain,
  Plus,
  Minus,
  AlertTriangle,
  MapPin,
  ArrowUpDown
} from 'lucide-react';
import { AppState } from '../types';

interface QuickReturnModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onExecuteReturn: (
    fromLocationId: string,
    toLocationId: string,
    equipmentId: string,
    quantity: number,
    isDamageReport: boolean,
    notes?: string
  ) => void;
  defaultFromLocationId?: string;
  defaultEquipmentId?: string;
}

export const QuickReturnModal: React.FC<QuickReturnModalProps> = ({
  isOpen,
  onClose,
  state,
  onExecuteReturn,
  defaultFromLocationId,
  defaultEquipmentId,
}) => {
  const externalLocations = state.locations.filter(l => !(l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
  const internalBases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
  const maintenanceLocation = state.locations.find(l => l.type === 'maintenance') || externalLocations[0];

  const [fromLocId, setFromLocId] = useState<string>('');
  const [toLocId, setToLocId] = useState<string>('');
  const [selectedEqId, setSelectedEqId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [isDamageReport, setIsDamageReport] = useState<boolean>(false);
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Synchronize cleanly when opening or parameters change
  useEffect(() => {
    if (isOpen) {
      const ext = state.locations.filter(l => !(l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
      const bases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
      const eqs = (state.equipments || []).filter(e => e.active !== false);

      const initialFrom = defaultFromLocationId || ext[0]?.id || state.locations[0]?.id || '';
      const initialTo = bases[0]?.id || state.locations[0]?.id || '';
      const initialEq = defaultEquipmentId || eqs[0]?.id || '';

      setFromLocId(initialFrom);
      setToLocId(initialTo);
      setSelectedEqId(initialEq);
      setQuantity(1);
      setIsDamageReport(false);
      setNotes('');
      setErrorMsg(null);
    }
  }, [isOpen, defaultFromLocationId, defaultEquipmentId, state.locations, state.equipments]);

  if (!isOpen) return null;

  const currentExternalQty = state.stocks?.[fromLocId]?.[selectedEqId] ?? 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fromLocId) {
      setErrorMsg('Veuillez sélectionner le lieu de provenance du matériel.');
      return;
    }
    if (!selectedEqId) {
      setErrorMsg('Veuillez sélectionner le matériel à rapatrier.');
      return;
    }
    const targetBaseId = isDamageReport && maintenanceLocation ? maintenanceLocation.id : toLocId;
    if (!targetBaseId) {
      setErrorMsg('Veuillez sélectionner le poste de secours destinataire.');
      return;
    }
    if (quantity <= 0) {
      setErrorMsg('La quantité à rapatrier doit être supérieure à zéro.');
      return;
    }

    onExecuteReturn(
      fromLocId,
      targetBaseId,
      selectedEqId,
      quantity,
      isDamageReport,
      notes.trim() || undefined
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[94vh] text-slate-900 dark:text-white transition-colors">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 bg-slate-50 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center shrink-0 ${
              isDamageReport 
                ? 'bg-amber-100 dark:bg-amber-500/20 border border-amber-300 dark:border-amber-400/40 text-amber-800 dark:text-amber-400' 
                : 'bg-emerald-100 dark:bg-emerald-500/20 border border-emerald-300 dark:border-emerald-400/40 text-emerald-800 dark:text-emerald-400'
            }`}>
              {isDamageReport ? <Wrench className="w-4 h-4 sm:w-5 sm:h-5" /> : <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />}
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white tracking-tight truncate">
                {isDamageReport ? 'Signaler Avarie / Atelier' : 'Rapatriement de Matériel'}
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
                {isDamageReport ? 'Bascule l\'équipement vers la révision' : 'Réintègre l\'équipement au poste de secours'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors p-1 shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 sm:space-y-5 overflow-y-auto flex-1 overscroll-contain">
          {errorMsg && (
            <div className="p-3 bg-rose-100 dark:bg-red-950/80 border border-rose-300 dark:border-red-700 rounded-xl text-xs sm:text-sm text-rose-900 dark:text-red-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Toggle Type d'Action */}
          <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 gap-1">
            <button
              type="button"
              onClick={() => setIsDamageReport(false)}
              className={`py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer min-h-[38px] ${
                !isDamageReport
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Rapatriement Normal
            </button>
            <button
              type="button"
              onClick={() => setIsDamageReport(true)}
              className={`py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer min-h-[38px] ${
                isDamageReport
                  ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Avarie / Révision
            </button>
          </div>

          {/* Lieu Source (Provenance) */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">
              {isDamageReport ? 'Poste ou lieu où se trouve le matériel abîmé :' : 'Provenance du matériel restitué :'}
            </label>
            <select
              value={fromLocId}
              onChange={e => setFromLocId(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
            >
              {state.locations
                .filter(l => l.active !== false)
                .map(loc => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} {loc.isInternalBase ? '(Poste de secours)' : '(Lieu d\'évacuation / Extérieur)'}
                  </option>
                ))}
            </select>
          </div>

          {/* Équipement */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center justify-between gap-1">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Matériel concerné :</label>
              <span className="text-xs text-slate-600 dark:text-slate-400">
                Quantité actuellement sur place : <strong className="font-mono text-slate-900 dark:text-white">{currentExternalQty}</strong>
              </span>
            </div>
            <select
              value={selectedEqId}
              onChange={e => setSelectedEqId(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
            >
              {(state.equipments || [])
                .filter(e => e.active !== false)
                .map(eq => (
                  <option key={eq.id} value={eq.id}>
                    {eq.name} ({eq.category})
                  </option>
                ))}
            </select>
          </div>

          {/* Quantité avec saisie au clavier et boutons +/- */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Nombre d'unités à déplacer :</label>
            <div className="flex items-center gap-3">
              <div className="flex items-center bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl p-1">
                <button
                  type="button"
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center touch-manipulation cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={e => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-14 text-center font-mono font-black text-sm text-slate-900 dark:text-white bg-transparent focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setQuantity(q => q + 1)}
                  className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center touch-manipulation cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <span className="text-xs text-slate-600 dark:text-slate-400">unité(s) à rapatrier</span>
            </div>
          </div>

          {/* Destination */}
          {!isDamageReport && (
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">
                Poste de destination (où le matériel est réintégré) :
              </label>
              <select
                value={toLocId}
                onChange={e => setToLocId(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
              >
                {internalBases.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.name} {b.altitude ? `(${b.altitude}m)` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Note / Motif */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">
              {isDamageReport ? 'Motif de l\'avarie :' : 'Note facultative (véhicule, pisteur, observations) :'}
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder={
                isDamageReport
                  ? 'Ex: Valve fuyarde, sangle arrachée, enveloppe percée...'
                  : 'Ex: Rapporté par ambulance des Aravis, navette 17h, Dr Martin...'
              }
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-3 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-center min-h-[38px] cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer min-h-[42px] shadow-sm ${
                isDamageReport
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-emerald-600 text-white hover:bg-emerald-500'
              }`}
            >
              <Check className="w-4 h-4 shrink-0" />
              <span>
                {isDamageReport ? 'Confirmer l\'envoi à l\'Atelier' : 'Valider le Rapatriement'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface InterBaseTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onExecuteTransfer: (
    fromBaseId: string,
    toBaseId: string,
    equipmentId: string,
    quantity: number,
    notes?: string
  ) => void;
  defaultToBaseId?: string;
  defaultEquipmentId?: string;
}

export const InterBaseTransferModal: React.FC<InterBaseTransferModalProps> = ({
  isOpen,
  onClose,
  state,
  onExecuteTransfer,
  defaultToBaseId,
  defaultEquipmentId,
}) => {
  const internalBases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);

  const [fromBaseId, setFromBaseId] = useState<string>('');
  const [toBaseId, setToBaseId] = useState<string>('');
  const [selectedEqId, setSelectedEqId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const bases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
      const eqs = (state.equipments || []).filter(e => e.active !== false);

      const targetTo = defaultToBaseId && bases.some(b => b.id === defaultToBaseId)
        ? defaultToBaseId
        : (bases.length > 1 ? bases[1].id : bases[0]?.id || '');

      const sourceFrom = bases.find(b => b.id !== targetTo)?.id || bases[0]?.id || '';

      const targetEq = defaultEquipmentId && eqs.some(e => e.id === defaultEquipmentId)
        ? defaultEquipmentId
        : (eqs[0]?.id || '');

      setFromBaseId(sourceFrom);
      setToBaseId(targetTo);
      setSelectedEqId(targetEq);
      setQuantity(1);
      setNotes('');
      setErrorMsg(null);
    }
  }, [isOpen, defaultToBaseId, defaultEquipmentId, state.locations, state.equipments]);

  if (!isOpen) return null;

  const currentAvailable = state.stocks?.[fromBaseId]?.[selectedEqId] ?? 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fromBaseId) {
      setErrorMsg('Veuillez sélectionner le poste d\'origine.');
      return;
    }
    if (!toBaseId) {
      setErrorMsg('Veuillez sélectionner le poste destinataire.');
      return;
    }
    if (fromBaseId === toBaseId) {
      setErrorMsg('Le poste d\'origine et le poste destinataire doivent être différents.');
      return;
    }
    if (!selectedEqId) {
      setErrorMsg('Veuillez sélectionner un matériel.');
      return;
    }
    if (quantity <= 0) {
      setErrorMsg('Veuillez spécifier une quantité supérieure à zéro.');
      return;
    }

    onExecuteTransfer(fromBaseId, toBaseId, selectedEqId, quantity, notes.trim() || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[94vh] text-slate-900 dark:text-white transition-colors">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 bg-slate-50 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-100 dark:bg-sky-500/20 border border-sky-300 dark:border-sky-400/40 flex items-center justify-center text-sky-700 dark:text-sky-400 shrink-0">
              <Mountain className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white tracking-tight truncate">
                Réapprovisionnement & Transfert de Matériel
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
                Faire monter du renfort vers un poste ou rééquilibrer les stocks
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors p-1 shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 overscroll-contain">
          {errorMsg && (
            <div className="p-3 bg-rose-100 dark:bg-red-950/80 border border-rose-300 dark:border-red-700 rounded-xl text-xs sm:text-sm text-rose-900 dark:text-red-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Poste d'origine (Départ) :</label>
              <select
                value={fromBaseId}
                onChange={e => {
                  const val = e.target.value;
                  setFromBaseId(val);
                  if (val === toBaseId) {
                    const other = internalBases.find(b => b.id !== val);
                    if (other) setToBaseId(other.id);
                  }
                }}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
              >
                {internalBases.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.name.split('(')[0]} {b.altitude ? `(${b.altitude}m)` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Poste destinataire (À réapprovisionner) :</label>
              <select
                value={toBaseId}
                onChange={e => setToBaseId(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
              >
                {internalBases.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.name.split('(')[0]} {b.altitude ? `(${b.altitude}m)` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center justify-between gap-1">
              <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Matériel transféré / réapprovisionné :</label>
              <span className="text-xs text-slate-600 dark:text-slate-400">
                Disponible au départ : <strong className="font-mono text-slate-900 dark:text-white">{currentAvailable}</strong>
              </span>
            </div>
            <select
              value={selectedEqId}
              onChange={e => setSelectedEqId(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500 min-h-[40px] cursor-pointer"
            >
              {(state.equipments || []).map(eq => (
                <option key={eq.id} value={eq.id}>
                  {eq.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Quantité :</label>
            <div className="flex items-center gap-3">
              <div className="flex items-center bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl p-1">
                <button
                  type="button"
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center touch-manipulation cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={e => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-14 text-center font-mono font-black text-sm text-slate-900 dark:text-white bg-transparent focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setQuantity(q => q + 1)}
                  className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 flex items-center justify-center touch-manipulation cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <span className="text-xs text-slate-600 dark:text-slate-400">unité(s)</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-300">Note de transfert (facultatif) :</label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Ex: Monté en télécabine par pisteur Thomas, réapprovisionnement régulation..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 min-h-[38px]"
            />
          </div>

          <div className="pt-3 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-center min-h-[38px] cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-sky-600 hover:bg-sky-500 text-white shadow-md flex items-center justify-center gap-2 cursor-pointer min-h-[42px]"
            >
              <Check className="w-4 h-4 shrink-0" />
              <span>Valider le Réapprovisionnement</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
