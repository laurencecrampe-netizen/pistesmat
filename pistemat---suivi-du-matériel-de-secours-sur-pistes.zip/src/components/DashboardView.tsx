import React, { useState, useEffect, useRef } from 'react';
import { 
  Mountain, 
  AlertTriangle, 
  CheckCircle2, 
  Building2, 
  Hospital, 
  Wrench, 
  RotateCcw, 
  ArrowRight,
  ArrowUpDown,
  MapPin,
  Sparkles,
  HelpCircle,
  X,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause
} from 'lucide-react';
import { AppState } from '../types';

interface DashboardViewProps {
  state: AppState;
  onOpenNewIncident: () => void;
  onOpenQuickReturnWithParams: (fromLocationId: string, equipmentId: string) => void;
  onOpenQuickReturn: () => void;
  onOpenInterBaseTransfer: () => void;
  onOpenInterBaseTransferWithParams?: (toBaseId?: string, equipmentId?: string) => void;
  onOpenWelcomeGuide?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  state,
  onOpenNewIncident,
  onOpenQuickReturnWithParams,
  onOpenQuickReturn,
  onOpenInterBaseTransfer,
  onOpenInterBaseTransferWithParams,
  onOpenWelcomeGuide,
}) => {
  const [isBannerDismissed, setIsBannerDismissed] = useState<boolean>(
    () => localStorage.getItem('pistemat_banner_dismissed') === 'true'
  );

  // Secure location filtering ensuring no locations are dropped due to missing active flags
  const internalBases = state.locations.filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);
  const externalLocations = state.locations.filter(l => !(l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false);

  // Horizontal scroll ticker state for postes
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isAutoScrolling, setIsAutoScrolling] = useState<boolean>(true);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [tickerFilter, setTickerFilter] = useState<'shortages' | 'all'>('shortages');
  const touchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleTouchStart = () => {
    if (touchTimeoutRef.current) clearTimeout(touchTimeoutRef.current);
    setIsHovered(true);
  };

  const handleTouchEnd = () => {
    if (touchTimeoutRef.current) clearTimeout(touchTimeoutRef.current);
    touchTimeoutRef.current = setTimeout(() => {
      setIsHovered(false);
    }, 3500);
  };

  // Group equipment shortages per patrol base / storage location
  interface BaseStatusSummary {
    id: string;
    name: string;
    altitude?: number;
    contact?: string;
    hasShortage: boolean;
    shortageItems: {
      equipmentId: string;
      equipmentName: string;
      currentQty: number;
      minThreshold: number;
    }[];
    totalItemsTracked: number;
  }

  const baseSummaries: BaseStatusSummary[] = internalBases.map(base => {
    const shortageItems: BaseStatusSummary['shortageItems'] = [];
    const activeEquipments = (state.equipments || []).filter(e => e.active !== false);

    activeEquipments.forEach(eq => {
      const qty = state.stocks?.[base.id]?.[eq.id] ?? 0;
      const min = state.minThresholds?.[base.id]?.[eq.id] ?? eq.defaultMinThreshold;
      if (qty <= min) {
        shortageItems.push({
          equipmentId: eq.id,
          equipmentName: eq.name.split('(')[0].trim(),
          currentQty: qty,
          minThreshold: min,
        });
      }
    });

    return {
      id: base.id,
      name: base.name.split('(')[0].trim(),
      altitude: base.altitude,
      contact: base.contact,
      hasShortage: shortageItems.length > 0,
      shortageItems,
      totalItemsTracked: activeEquipments.length,
    };
  });

  const basesInShortage = baseSummaries.filter(b => b.hasShortage);

  // Flattened critical alerts list
  const criticalShortages = baseSummaries.flatMap(b => 
    b.shortageItems.map(item => ({
      baseName: b.name,
      equipmentName: item.equipmentName,
      currentQty: item.currentQty,
      minThreshold: item.minThreshold,
    }))
  );

  // Auto-scroll loop moving horizontally right-to-left
  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el || !isAutoScrolling || isHovered) return;

    const interval = setInterval(() => {
      if (!el) return;
      if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 2) {
        el.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        el.scrollLeft += 1;
      }
    }, 35);

    return () => clearInterval(interval);
  }, [isAutoScrolling, isHovered, tickerFilter, baseSummaries.length]);

  const handleScrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -280, behavior: 'smooth' });
    }
  };

  const handleScrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 280, behavior: 'smooth' });
    }
  };

  // Horizontal scroll state for Postes de Secours section
  const basesScrollContainerRef = useRef<HTMLDivElement>(null);
  const [isBasesAutoScrolling, setIsBasesAutoScrolling] = useState<boolean>(false);
  const [isBasesHovered, setIsBasesHovered] = useState<boolean>(false);
  const [basesFilter, setBasesFilter] = useState<'all' | 'alerts'>('all');
  const basesTouchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleBasesTouchStart = () => {
    if (basesTouchTimeoutRef.current) clearTimeout(basesTouchTimeoutRef.current);
    setIsBasesHovered(true);
  };

  const handleBasesTouchEnd = () => {
    if (basesTouchTimeoutRef.current) clearTimeout(basesTouchTimeoutRef.current);
    basesTouchTimeoutRef.current = setTimeout(() => {
      setIsBasesHovered(false);
    }, 3500);
  };

  const displayedBases = internalBases.filter(b => {
    if (basesFilter === 'alerts') {
      return basesInShortage.some(s => s.id === b.id);
    }
    return true;
  });

  useEffect(() => {
    const el = basesScrollContainerRef.current;
    if (!el || !isBasesAutoScrolling || isBasesHovered) return;

    const interval = setInterval(() => {
      if (!el) return;
      if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 2) {
        el.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        el.scrollLeft += 1;
      }
    }, 35);

    return () => clearInterval(interval);
  }, [isBasesAutoScrolling, isBasesHovered, basesFilter, displayedBases.length]);

  const handleBasesScrollLeft = () => {
    if (basesScrollContainerRef.current) {
      basesScrollContainerRef.current.scrollBy({ left: -340, behavior: 'smooth' });
    }
  };

  const handleBasesScrollRight = () => {
    if (basesScrollContainerRef.current) {
      basesScrollContainerRef.current.scrollBy({ left: 340, behavior: 'smooth' });
    }
  };

  // Calculate total critical equipment deployed outside
  const getTotalOutside = (locId?: string, eqId?: string) => {
    if (!locId || !state?.stocks) return 0;
    const locStocks = state.stocks[locId];
    if (!locStocks || typeof locStocks !== 'object') return 0;
    if (eqId) return locStocks[eqId] ?? 0;
    return Object.values(locStocks).reduce((acc, v) => acc + (typeof v === 'number' && v > 0 ? v : 0), 0);
  };

  const totalGrandOutside = externalLocations.reduce((sum, l) => sum + getTotalOutside(l.id), 0);

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Message de bienvenue à l'attention des nouveaux utilisateurs */}
      {!isBannerDismissed && (
        <div className="bg-sky-50 dark:bg-gradient-to-r dark:from-sky-950/85 dark:via-slate-900 dark:to-slate-900 border border-sky-300 dark:border-sky-800/70 rounded-2xl p-4 sm:p-5 shadow-sm dark:shadow-xl relative flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors">
          <div className="flex items-start gap-3.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-sky-200/70 dark:bg-sky-500/20 border border-sky-300 dark:border-sky-400/30 flex items-center justify-center text-sky-800 dark:text-sky-400 shrink-0 mt-0.5 shadow-inner">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="space-y-1.5 min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Bienvenue sur PisteMat !
                </h2>
                <span className="text-[11px] font-bold uppercase tracking-wider text-sky-800 bg-sky-100 border border-sky-300 dark:text-sky-300 dark:bg-sky-950 dark:border-sky-800 rounded px-2 py-0.5">
                  Nouveau pisteur
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 max-w-2xl leading-relaxed">
                PisteMat permet de suivre et tracer le matériel de secours d'altitude (MID, colliers, attelles) sans scanner ni QR code. Lors d'une évacuation vers un cabinet médical ou hôpital, le matériel est automatiquement déduit.
              </p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 pt-1 text-xs text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-semibold text-red-700 dark:text-red-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600 shrink-0" />
                  1. Nouveau Secours (déduction automatique)
                </span>
                <span className="flex items-center gap-1.5 font-semibold text-emerald-700 dark:text-emerald-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 shrink-0" />
                  2. Rapatriement (réintégration en stock)
                </span>
                <span className="flex items-center gap-1.5 font-semibold text-amber-700 dark:text-amber-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600 shrink-0" />
                  3. Fermeture 17h (récupération finale)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
            {onOpenWelcomeGuide && (
              <button
                onClick={onOpenWelcomeGuide}
                className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-95"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Guide pas-à-pas</span>
              </button>
            )}
            <button
              onClick={() => {
                setIsBannerDismissed(true);
                localStorage.setItem('pistemat_banner_dismissed', 'true');
              }}
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-xl hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Masquer ce message"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Top Banner Alert with Horizontal Scrolling Postes (if critical shortages) */}
      {criticalShortages.length > 0 && (
        <div className="bg-red-50 dark:bg-gradient-to-r dark:from-red-950/85 dark:via-red-900/60 dark:to-slate-900 border-2 border-red-400 dark:border-red-700 rounded-2xl p-4 sm:p-5 shadow-md space-y-3.5 transition-colors">
          {/* Header du bandeau : Titre, actions prioritaires et contrôles de défilement horizontal */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-600/30 border border-red-300 dark:border-red-500/50 flex items-center justify-center text-red-600 dark:text-red-400 shrink-0 animate-pulse">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-sm sm:text-base font-extrabold text-red-950 dark:text-white tracking-tight">
                    Seuil Critique : {criticalShortages.length} matériel(s) sous tension
                  </h2>
                  <span className="text-xs font-mono bg-red-600 text-white font-bold px-2.5 py-0.5 rounded-full whitespace-nowrap shadow-xs">
                    Action Requise
                  </span>
                </div>
                <p className="text-xs text-red-800 dark:text-red-300 font-medium">
                  {basesInShortage.length} poste(s) touché(s) sur {internalBases.length} lieux de stockage du domaine skiable
                </p>
              </div>
            </div>

            {/* Boutons d'action et commandes de défilement */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {/* Filtre : Postes en tension vs Tous les postes */}
              <div className="flex items-center bg-white dark:bg-slate-900 border border-red-300 dark:border-red-800 rounded-xl p-0.5 shadow-xs">
                <button
                  type="button"
                  onClick={() => setTickerFilter('shortages')}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    tickerFilter === 'shortages'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-red-900 dark:text-red-200 hover:bg-red-100 dark:hover:bg-slate-800'
                  }`}
                  title="Afficher uniquement les postes ayant du matériel sous tension"
                >
                  En tension ({basesInShortage.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTickerFilter('all')}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    tickerFilter === 'all'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-red-900 dark:text-red-200 hover:bg-red-100 dark:hover:bg-slate-800'
                  }`}
                  title="Afficher l'ensemble des postes de stockage de la station"
                >
                  Tous les postes ({internalBases.length})
                </button>
              </div>

              {/* Contrôles de défilement horizontal (Gauche, Droite, Pause/Play) */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-red-300 dark:border-red-800 rounded-xl p-0.5 shadow-xs">
                <button
                  type="button"
                  onClick={handleScrollLeft}
                  className="p-1.5 text-red-900 dark:text-red-200 hover:bg-red-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  title="Faire défiler vers la gauche"
                  aria-label="Défiler vers la gauche"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsAutoScrolling(!isAutoScrolling)}
                  className="p-1.5 text-red-900 dark:text-red-200 hover:bg-red-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  title={isAutoScrolling ? "Mettre le défilement automatique en pause" : "Activer le défilement automatique"}
                  aria-label="Lecture ou pause du défilement"
                >
                  {isAutoScrolling ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={handleScrollRight}
                  className="p-1.5 text-red-900 dark:text-red-200 hover:bg-red-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  title="Faire défiler vers la droite"
                  aria-label="Défiler vers la droite"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Boutons d'intervention rapide */}
              <button
                onClick={onOpenInterBaseTransfer}
                className="px-3 sm:px-3.5 py-1.5 sm:py-2 text-xs sm:text-sm font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-md flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap min-h-[36px]"
              >
                <ArrowUpDown className="w-4 h-4 shrink-0" />
                <span>Renfort</span>
              </button>
              <button
                onClick={onOpenQuickReturn}
                className="px-3 sm:px-3.5 py-1.5 sm:py-2 text-xs sm:text-sm font-bold text-slate-800 dark:text-white bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap min-h-[36px] shadow-xs"
              >
                <RotateCcw className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Rapatrier</span>
              </button>
            </div>
          </div>

          {/* Rail de défilement horizontal des postes (défile de droite à gauche avec pause au survol) */}
          <div
            ref={scrollContainerRef}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className="flex items-stretch gap-3 overflow-x-auto pb-2 pt-1 scroll-smooth no-scrollbar cursor-grab active:cursor-grabbing select-none"
            style={{ scrollbarWidth: 'thin' }}
          >
            {(tickerFilter === 'shortages' ? basesInShortage : baseSummaries).map(base => {
              const isAlert = base.hasShortage;
              return (
                <div
                  key={base.id}
                  className={`shrink-0 w-72 sm:w-80 rounded-xl p-3 border transition-all flex flex-col justify-between shadow-xs ${
                    isAlert
                      ? 'bg-white/95 dark:bg-slate-900/95 border-red-300 dark:border-red-800/80 hover:border-red-500'
                      : 'bg-white/80 dark:bg-slate-900/70 border-emerald-300 dark:border-emerald-800/60'
                  }`}
                >
                  {/* Titre du poste & statut */}
                  <div>
                    <div className="flex items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 mb-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Mountain className={`w-4 h-4 shrink-0 ${isAlert ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                        <span className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                          {base.name}
                        </span>
                      </div>
                      {base.altitude && (
                        <span className="text-[10px] font-mono font-bold text-sky-800 bg-sky-100 dark:text-sky-300 dark:bg-sky-950 px-1.5 py-0.5 rounded border border-sky-300 dark:border-sky-800 shrink-0">
                          {base.altitude}m
                        </span>
                      )}
                    </div>

                    {/* Détails du matériel sous tension pour ce poste */}
                    {isAlert ? (
                      <div className="space-y-1.5 max-h-24 overflow-y-auto pr-1">
                        {base.shortageItems.map(item => (
                          <div
                            key={item.equipmentId}
                            className="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-red-50/80 dark:bg-red-950/50 border border-red-200 dark:border-red-900/60"
                          >
                            <span className="font-semibold text-red-950 dark:text-red-200 truncate pr-2">
                              {item.equipmentName}
                            </span>
                            <span className="font-mono font-bold text-[11px] px-1.5 py-0.5 rounded bg-red-600 text-white shrink-0">
                              {item.currentQty} / min {item.minThreshold}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-3 flex items-center justify-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Tous matériels au-dessus du seuil</span>
                      </div>
                    )}
                  </div>

                  {/* Bas de carte poste avec bouton renfort ciblé */}
                  <div className="pt-2 mt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      {isAlert ? `${base.shortageItems.length} matériel(s) sous seuil` : 'Stock opérationnel'}
                    </span>
                    {isAlert && (
                      <button
                        type="button"
                        onClick={() => {
                          if (onOpenInterBaseTransferWithParams) {
                            onOpenInterBaseTransferWithParams(base.id, base.shortageItems[0]?.equipmentId);
                          } else {
                            onOpenInterBaseTransfer();
                          }
                        }}
                        className="text-[11px] font-bold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
                        title={`Réapprovisionner ${base.name} en ${base.shortageItems[0]?.equipmentName || 'matériel'}`}
                      >
                        <ArrowUpDown className="w-3 h-3" />
                        <span>Réapprovisionner</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[11px] text-red-800 dark:text-red-300/80 pt-0.5">
            <span className="italic flex items-center gap-1">
              <span>Astuce :</span> Faites glisser horizontalement ou utilisez les flèches pour faire défiler les postes. Le défilement se met en pause automatiquement au survol.
            </span>
            <span className="font-mono font-semibold">
              {basesInShortage.length} poste(s) sous surveillance
            </span>
          </div>
        </div>
      )}

      {/* Synthèse immédiate : Lieux d'Évacuation & Décompte du Matériel à Récupérer */}
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm dark:shadow-lg space-y-4 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              totalGrandOutside > 0 
                ? 'bg-amber-100 text-amber-800 border border-amber-300 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/30' 
                : 'bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/30'
            }`}>
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Lieux d'Évacuation & Matériel à Récupérer
                </h2>
                <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full ${
                  totalGrandOutside > 0 
                    ? 'bg-amber-100 text-amber-950 border border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800' 
                    : 'bg-emerald-100 text-emerald-950 border border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                }`}>
                  {totalGrandOutside} pièce(s) à récupérer
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                Pointez et rapatriez les immobilisations laissées au Cabinet Médical, Hôpital ou Ambulances
              </p>
            </div>
          </div>

          <button
            onClick={onOpenQuickReturn}
            className="self-start sm:self-auto px-4 py-2 text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md flex items-center gap-2 transition-all cursor-pointer min-h-[38px]"
          >
            <RotateCcw className="w-4 h-4 text-white shrink-0" />
            <span>Rapatrier du matériel</span>
          </button>
        </div>

        {/* Badges Lieux d'évacuation avec décompte direct */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {externalLocations.map(loc => {
            const count = getTotalOutside(loc.id);
            return (
              <div 
                key={loc.id} 
                className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-2xs"
              >
                <div className="min-w-0">
                  <span className="font-bold text-sm text-slate-900 dark:text-white block truncate">{loc.name}</span>
                  <span className="text-xs text-slate-600 dark:text-slate-400">
                    {loc.contact || (loc.type === 'hospital' ? 'Urgences' : loc.type === 'medical_cabinet' ? 'Cabinet médical' : 'Extérieur')}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`font-mono font-bold text-xs sm:text-sm px-2.5 py-1 rounded-lg border ${
                    count > 0 
                      ? 'text-amber-950 bg-amber-100 border-amber-300 dark:text-amber-300 dark:bg-amber-950 dark:border-amber-800' 
                      : 'text-slate-600 bg-slate-200/80 border-slate-300 dark:text-slate-400 dark:bg-slate-800/80 dark:border-slate-700'
                  }`}>
                    {count} {count > 1 ? 'pièces' : 'pièce'}
                  </span>
                  {count > 0 && (
                    <button
                      onClick={() => onOpenQuickReturnWithParams(loc.id, state.equipments[0]?.id || '')}
                      className="p-2 text-xs text-emerald-800 dark:text-emerald-300 hover:text-white bg-emerald-100 hover:bg-emerald-600 dark:bg-emerald-950/80 dark:hover:bg-emerald-900 border border-emerald-300 dark:border-emerald-800 rounded-lg transition-colors cursor-pointer"
                      title={`Rapatrier depuis ${loc.name}`}
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section : Postes de Secours sur le Domaine Skiable (Défilement horizontal droite-gauche) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                <Mountain className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0" />
                <span>Postes de Secours sur le Domaine Skiable</span>
              </h2>
              <span className="text-xs font-mono font-bold bg-sky-100 text-sky-800 border border-sky-300 dark:bg-sky-950 dark:text-sky-300 dark:border-sky-800 px-2.5 py-0.5 rounded-full">
                {internalBases.length} lieux de stockage
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Disponibilité en temps réel déduite automatiquement des interventions radio
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filtre : Tous les postes vs Sous tension */}
            <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl p-0.5 shadow-xs">
              <button
                type="button"
                onClick={() => setBasesFilter('all')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                  basesFilter === 'all'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title="Afficher tous les postes de la station"
              >
                Tous ({internalBases.length})
              </button>
              <button
                type="button"
                onClick={() => setBasesFilter('alerts')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                  basesFilter === 'alerts'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title="Afficher uniquement les postes ayant du matériel sous seuil"
              >
                En alerte ({basesInShortage.length})
              </button>
            </div>

            {/* Contrôles de défilement horizontal (Gauche, Droite, Pause/Play) */}
            <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl p-0.5 shadow-xs">
              <button
                type="button"
                onClick={handleBasesScrollLeft}
                className="p-1.5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Faire défiler vers la gauche"
                aria-label="Défiler vers la gauche"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsBasesAutoScrolling(!isBasesAutoScrolling)}
                className="p-1.5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title={isBasesAutoScrolling ? "Mettre le défilement automatique en pause" : "Activer le défilement automatique"}
                aria-label="Lecture ou pause du défilement"
              >
                {isBasesAutoScrolling ? <Pause className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" /> : <Play className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={handleBasesScrollRight}
                className="p-1.5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Faire défiler vers la droite"
                aria-label="Défiler vers la droite"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={onOpenInterBaseTransfer}
              className="px-3.5 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl flex items-center gap-2 transition-colors min-h-[36px] cursor-pointer"
            >
              <ArrowUpDown className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <span>Réapprovisionner un poste</span>
            </button>
          </div>
        </div>

        {/* Rail de défilement horizontal des postes */}
        <div
          ref={basesScrollContainerRef}
          onMouseEnter={() => setIsBasesHovered(true)}
          onMouseLeave={() => setIsBasesHovered(false)}
          onTouchStart={handleBasesTouchStart}
          onTouchEnd={handleBasesTouchEnd}
          className="flex items-stretch gap-4 overflow-x-auto pb-3 pt-1 scroll-smooth no-scrollbar cursor-grab active:cursor-grabbing select-none"
          style={{ scrollbarWidth: 'thin' }}
        >
          {displayedBases.map(base => {
            return (
              <div
                key={base.id}
                className="shrink-0 w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 hover:border-sky-400 dark:hover:border-slate-700 rounded-2xl p-4 sm:p-5 shadow-sm dark:shadow-lg flex flex-col justify-between transition-all"
              >
                {/* Header Poste */}
                <div className="space-y-1 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white tracking-tight leading-snug truncate">
                      {base.name}
                    </h3>
                    {base.altitude && (
                      <span className="text-xs font-mono font-bold text-sky-800 bg-sky-100 border border-sky-300 dark:text-sky-300 dark:bg-sky-950 dark:border-sky-800 px-2 py-0.5 rounded-lg shrink-0">
                        {base.altitude}m
                      </span>
                    )}
                  </div>
                  {base.contact && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
                      {base.contact}
                    </p>
                  )}
                </div>

                {/* Liste des matériels suivis au poste */}
                <div className="py-3.5 space-y-2.5">
                  {(state.equipments || []).filter(e => e.active !== false).map(eq => {
                    const currentQty = state.stocks?.[base.id]?.[eq.id] ?? 0;
                    const min = state.minThresholds?.[base.id]?.[eq.id] ?? eq.defaultMinThreshold;

                    let statusColor = 'text-emerald-950 bg-emerald-100 border-emerald-300 dark:text-emerald-200 dark:bg-emerald-950/70 dark:border-emerald-800';
                    let statusDot = 'bg-emerald-600 dark:bg-emerald-400';

                    if (currentQty < 0) {
                      statusColor = 'text-rose-950 bg-rose-100 border-2 border-rose-400 dark:text-rose-200 dark:bg-rose-950 dark:border-rose-700 animate-pulse font-black';
                      statusDot = 'bg-rose-600 dark:bg-rose-500';
                    } else if (currentQty === 0) {
                      statusColor = 'text-rose-950 bg-rose-100 border border-rose-300 dark:text-rose-200 dark:bg-rose-950/80 dark:border-rose-800 font-extrabold';
                      statusDot = 'bg-rose-600 dark:bg-rose-500';
                    } else if (currentQty <= min) {
                      statusColor = 'text-amber-950 bg-amber-100 border border-amber-300 dark:text-amber-200 dark:bg-amber-950/80 dark:border-amber-700 font-bold';
                      statusDot = 'bg-amber-600 dark:bg-amber-400';
                    }

                    return (
                      <div
                        key={eq.id}
                        className="flex items-center justify-between text-sm py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 gap-2"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${statusDot}`} />
                          <span className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                            {eq.name.split('(')[0].trim()}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono font-medium">
                            min:{min}
                          </span>
                          <span className={`font-mono font-bold text-sm px-2.5 py-0.5 rounded-lg border tabular-nums ${statusColor}`}>
                            {currentQty}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Footer Carte Poste */}
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-xs text-slate-600 dark:text-slate-400">
                    Dotation terrain
                  </span>
                  <button
                    onClick={onOpenNewIncident}
                    className="text-xs font-bold text-sky-700 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300 flex items-center gap-1.5 transition-colors p-1 cursor-pointer"
                  >
                    <span>Secours radio</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pied de section avec rappel de défilement */}
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
          <span className="italic flex items-center gap-1.5">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Défilement horizontal :</span>
            Faites glisser les postes ou utilisez les flèches pour parcourir l'ensemble des lieux de stockage.
          </span>
          <span className="font-mono font-medium">
            {displayedBases.length} poste(s) affiché(s)
          </span>
        </div>
      </div>
    </div>
  );
};
