import React, { useState, useEffect } from 'react';
import { AppState, RescueIncident, MovementLog, Location } from './types';
import { loadAppState, saveAppState, subscribeToStateChanges } from './lib/storage';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ClosingRecoveryView } from './components/ClosingRecoveryView';
import { HistoryView } from './components/HistoryView';
import { AdminView } from './components/AdminView';
import { NewIncidentModal } from './components/NewIncidentModal';
import { QuickReturnModal, InterBaseTransferModal } from './components/QuickActionModals';
import { WelcomeGuideModal } from './components/WelcomeGuideModal';
import { CheckCircle2, AlertTriangle, X } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<AppState>(() => loadAppState());
  const [activeTab, setActiveTab] = useState<'dashboard' | 'closing' | 'history' | 'admin'>('dashboard');

  // Modal states
  const [isNewIncidentOpen, setIsNewIncidentOpen] = useState<boolean>(false);
  const [isQuickReturnOpen, setIsQuickReturnOpen] = useState<boolean>(false);
  const [isInterBaseTransferOpen, setIsInterBaseTransferOpen] = useState<boolean>(false);
  const [isWelcomeGuideOpen, setIsWelcomeGuideOpen] = useState<boolean>(
    () => localStorage.getItem('pistemat_welcome_seen') !== 'true'
  );

  // Return modal pre-filled parameters
  const [returnFromLocId, setReturnFromLocId] = useState<string | undefined>(undefined);
  const [returnEqId, setReturnEqId] = useState<string | undefined>(undefined);

  // Transfer modal pre-filled parameters
  const [transferToBaseId, setTransferToBaseId] = useState<string | undefined>(undefined);
  const [transferEqId, setTransferEqId] = useState<string | undefined>(undefined);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'warning' } | null>(null);

  const showToast = (text: string, type: 'success' | 'warning' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Sync state across browser tabs and local network instances
  useEffect(() => {
    const unsubscribe = subscribeToStateChanges(() => {
      setState(loadAppState());
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // Save new rescue incident & deduct equipment
  const handleSaveIncident = (
    incident: RescueIncident,
    movements: MovementLog[],
    updatedStocks: Record<string, Record<string, number>>,
    newLocations?: Location[]
  ) => {
    const updatedLocations = newLocations && newLocations.length > 0
      ? [...state.locations, ...newLocations.filter(nl => !state.locations.some(l => l.id === nl.id))]
      : state.locations;

    const newState: AppState = {
      ...state,
      locations: updatedLocations,
      incidents: [incident, ...state.incidents],
      movements: [...movements, ...state.movements],
      stocks: updatedStocks,
    };
    setState(newState);
    saveAppState(newState);
    showToast(`Secours #${incident.number} enregistré. Matériel déduit automatiquement !`);
  };

  // Quick single-item return or damage reporting
  const handleExecuteReturn = (
    fromLocationId: string,
    toLocationId: string,
    equipmentId: string,
    quantity: number,
    isDamageReport: boolean,
    notes?: string
  ) => {
    const timestamp = new Date().toISOString();
    const newStocks = JSON.parse(JSON.stringify(state.stocks));

    const fromQty = newStocks[fromLocationId]?.[equipmentId] ?? 0;
    const toQty = newStocks[toLocationId]?.[equipmentId] ?? 0;

    if (!newStocks[fromLocationId]) newStocks[fromLocationId] = {};
    if (!newStocks[toLocationId]) newStocks[toLocationId] = {};

    newStocks[fromLocationId][equipmentId] = fromQty - quantity;
    newStocks[toLocationId][equipmentId] = toQty + quantity;

    const fromLoc = state.locations.find(l => l.id === fromLocationId);
    const toLoc = state.locations.find(l => l.id === toLocationId);
    const eq = state.equipments.find(e => e.id === equipmentId);

    const newMovement: MovementLog = {
      id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp,
      equipmentId,
      quantity,
      fromLocationId,
      toLocationId,
      type: isDamageReport ? 'flagged_damaged' : 'quick_return',
      notes: notes || (isDamageReport ? 'Matériel signalé en révision / percé' : 'Rapatriement manuel'),
    };

    const newState: AppState = {
      ...state,
      stocks: newStocks,
      movements: [newMovement, ...state.movements],
    };

    setState(newState);
    saveAppState(newState);

    if (isDamageReport) {
      showToast(`${quantity}x ${eq?.name.split('(')[0]} basculé vers l'Atelier en révision.`, 'warning');
    } else {
      showToast(`${quantity}x ${eq?.name.split('(')[0]} réintégré au ${toLoc?.name.split('(')[0]}.`);
    }
  };

  // Bulk recovery for Closing View (tout rapatrier d'un cabinet ou hôpital vers le Poste Central)
  const handleExecuteBulkRecovery = (fromLocationId: string, toLocationId: string) => {
    const timestamp = new Date().toISOString();
    const newStocks = JSON.parse(JSON.stringify(state.stocks));
    const newMovements: MovementLog[] = [];

    const fromLoc = state.locations.find(l => l.id === fromLocationId);
    const toLoc = state.locations.find(l => l.id === toLocationId);

    let count = 0;

    state.equipments.forEach(eq => {
      const qty = newStocks[fromLocationId]?.[eq.id] ?? 0;
      if (qty > 0) {
        if (!newStocks[fromLocationId]) newStocks[fromLocationId] = {};
        if (!newStocks[toLocationId]) newStocks[toLocationId] = {};

        const toQty = newStocks[toLocationId]?.[eq.id] ?? 0;
        newStocks[fromLocationId][eq.id] = 0;
        newStocks[toLocationId][eq.id] = toQty + qty;

        newMovements.push({
          id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          timestamp,
          equipmentId: eq.id,
          quantity: qty,
          fromLocationId,
          toLocationId,
          type: 'closing_recovery',
          notes: `Tournée de fermeture : Tout rapatrié de ${fromLoc?.name.split('(')[0]} vers ${toLoc?.name.split('(')[0]}`,
        });

        count += qty;
      }
    });

    const newState: AppState = {
      ...state,
      stocks: newStocks,
      movements: [...newMovements, ...state.movements],
    };

    setState(newState);
    saveAppState(newState);
    showToast(`Tournée validée : ${count} pièce(s) rapatriée(s) vers ${toLoc?.name.split('(')[0]}.`);
  };

  // Inter-base transfer (faire monter du renfort vers un poste d'altitude)
  const handleExecuteTransfer = (
    fromBaseId: string,
    toBaseId: string,
    equipmentId: string,
    quantity: number,
    notes?: string
  ) => {
    const timestamp = new Date().toISOString();
    const newStocks = JSON.parse(JSON.stringify(state.stocks));

    const fromQty = newStocks[fromBaseId]?.[equipmentId] ?? 0;
    const toQty = newStocks[toBaseId]?.[equipmentId] ?? 0;

    if (!newStocks[fromBaseId]) newStocks[fromBaseId] = {};
    if (!newStocks[toBaseId]) newStocks[toBaseId] = {};

    newStocks[fromBaseId][equipmentId] = fromQty - quantity;
    newStocks[toBaseId][equipmentId] = toQty + quantity;

    const fromLoc = state.locations.find(l => l.id === fromBaseId);
    const toLoc = state.locations.find(l => l.id === toBaseId);
    const eq = state.equipments.find(e => e.id === equipmentId);

    const newMovement: MovementLog = {
      id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp,
      equipmentId,
      quantity,
      fromLocationId: fromBaseId,
      toLocationId: toBaseId,
      type: 'inter_base_transfer',
      notes: notes || `Renfort en journée de ${fromLoc?.name.split('(')[0]} vers ${toLoc?.name.split('(')[0]}`,
    };

    const newState: AppState = {
      ...state,
      stocks: newStocks,
      movements: [newMovement, ...state.movements],
    };

    setState(newState);
    saveAppState(newState);
    showToast(`Transfert validé : ${quantity}x ${eq?.name.split('(')[0]} transféré(s) au ${toLoc?.name.split('(')[0]}.`);
  };

  // Cancel an incident with full equipment rollback
  const handleCancelIncident = (incidentId: string, reason: string) => {
    const incident = state.incidents.find(i => i.id === incidentId);
    if (!incident) return;
    if (incident.notes?.includes('[ANNULÉ]')) {
      showToast('Ce secours a déjà été annulé.', 'warning');
      return;
    }

    const timestamp = new Date().toISOString();
    const newStocks = JSON.parse(JSON.stringify(state.stocks));
    const newMovements: MovementLog[] = [];

    const wasStayedOnStation = incident.finalDestinationId === incident.patrolBaseId || incident.notes?.includes('resté en station');

    if (!wasStayedOnStation) {
      // Reverse deducted equipment back to patrol base
      incident.equipmentsUsed.forEach(item => {
        const baseQty = newStocks[incident.patrolBaseId]?.[item.equipmentId] ?? 0;
        if (!newStocks[incident.patrolBaseId]) newStocks[incident.patrolBaseId] = {};
        newStocks[incident.patrolBaseId][item.equipmentId] = baseQty + item.quantity;

        // If it was allocated to external destination, remove from destination
        if (incident.finalDestinationId && incident.finalDestinationId !== incident.patrolBaseId) {
          const destQty = newStocks[incident.finalDestinationId]?.[item.equipmentId] ?? 0;
          if (!newStocks[incident.finalDestinationId]) newStocks[incident.finalDestinationId] = {};
          newStocks[incident.finalDestinationId][item.equipmentId] = Math.max(0, destQty - item.quantity);
        }

        newMovements.push({
          id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          timestamp,
          equipmentId: item.equipmentId,
          quantity: item.quantity,
          fromLocationId: incident.finalDestinationId || incident.patrolBaseId,
          toLocationId: incident.patrolBaseId,
          incidentId,
          type: 'incident_cancellation',
          notes: `Annulation secours #${incident.number} : ${reason}`,
        });
      });
    } else {
      // Material stayed on station: log cancellation without altering stocks
      newMovements.push({
        id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
        timestamp,
        equipmentId: incident.equipmentsUsed[0]?.equipmentId || 'divers',
        quantity: 0,
        fromLocationId: incident.patrolBaseId,
        toLocationId: incident.patrolBaseId,
        incidentId,
        type: 'incident_cancellation',
        notes: `Annulation secours #${incident.number} : ${reason} (matériel était resté en station)`,
      });
    }

    const newState: AppState = {
      ...state,
      incidents: state.incidents.map(i => i.id === incidentId ? { ...i, notes: `[ANNULÉ] ${reason} - ${i.notes || ''}` } : i),
      stocks: newStocks,
      movements: [...newMovements, ...state.movements],
    };

    setState(newState);
    saveAppState(newState);
    showToast(`Secours #${incident.number} annulé. Tout le matériel a été restitué en stock au poste de départ.`, 'warning');
  };

  // Modify / Edit an existing movement log in Main Courante with automatic stock rebalancing
  const handleUpdateMovement = (
    movementId: string,
    updatedData: {
      equipmentId: string;
      quantity: number;
      fromLocationId: string;
      toLocationId: string;
      notes?: string;
      timestamp?: string;
    }
  ) => {
    const existingMovement = state.movements.find(m => m.id === movementId);
    if (!existingMovement) return;

    const newStocks = JSON.parse(JSON.stringify(state.stocks));

    // Revert old movement stock impact
    if (existingMovement.fromLocationId && existingMovement.equipmentId) {
      if (!newStocks[existingMovement.fromLocationId]) newStocks[existingMovement.fromLocationId] = {};
      const currentFrom = newStocks[existingMovement.fromLocationId][existingMovement.equipmentId] ?? 0;
      newStocks[existingMovement.fromLocationId][existingMovement.equipmentId] = currentFrom + existingMovement.quantity;
    }
    if (existingMovement.toLocationId && existingMovement.equipmentId) {
      if (!newStocks[existingMovement.toLocationId]) newStocks[existingMovement.toLocationId] = {};
      const currentTo = newStocks[existingMovement.toLocationId][existingMovement.equipmentId] ?? 0;
      newStocks[existingMovement.toLocationId][existingMovement.equipmentId] = Math.max(0, currentTo - existingMovement.quantity);
    }

    // Apply new movement stock impact
    if (updatedData.fromLocationId && updatedData.equipmentId) {
      if (!newStocks[updatedData.fromLocationId]) newStocks[updatedData.fromLocationId] = {};
      const currentFrom = newStocks[updatedData.fromLocationId][updatedData.equipmentId] ?? 0;
      newStocks[updatedData.fromLocationId][updatedData.equipmentId] = currentFrom - updatedData.quantity;
    }
    if (updatedData.toLocationId && updatedData.equipmentId) {
      if (!newStocks[updatedData.toLocationId]) newStocks[updatedData.toLocationId] = {};
      const currentTo = newStocks[updatedData.toLocationId][updatedData.equipmentId] ?? 0;
      newStocks[updatedData.toLocationId][updatedData.equipmentId] = currentTo + updatedData.quantity;
    }

    // Update movement
    const updatedMovements = state.movements.map(m => {
      if (m.id === movementId) {
        return {
          ...m,
          equipmentId: updatedData.equipmentId,
          quantity: updatedData.quantity,
          fromLocationId: updatedData.fromLocationId,
          toLocationId: updatedData.toLocationId,
          notes: updatedData.notes,
          timestamp: updatedData.timestamp || m.timestamp,
        };
      }
      return m;
    });

    // If movement is linked to an incident, update incident too
    let updatedIncidents = state.incidents;
    if (existingMovement.incidentId) {
      updatedIncidents = state.incidents.map(inc => {
        if (inc.id === existingMovement.incidentId) {
          const updatedEqUsed = inc.equipmentsUsed.map(eu => 
            eu.equipmentId === existingMovement.equipmentId 
              ? { equipmentId: updatedData.equipmentId, quantity: updatedData.quantity } 
              : eu
          );
          return {
            ...inc,
            patrolBaseId: updatedData.fromLocationId,
            finalDestinationId: updatedData.toLocationId,
            equipmentsUsed: updatedEqUsed,
            notes: updatedData.notes || inc.notes,
          };
        }
        return inc;
      });
    }

    const newState: AppState = {
      ...state,
      stocks: newStocks,
      movements: updatedMovements,
      incidents: updatedIncidents,
    };

    setState(newState);
    saveAppState(newState);
    showToast('Ligne de main courante modifiée et stocks réajustés avec succès !');
  };

  // Morning audit / stock recalibration
  const handleAuditStock = (
    locationId: string,
    equipmentId: string,
    newQuantity: number,
    reason: string
  ) => {
    const timestamp = new Date().toISOString();
    const newStocks = JSON.parse(JSON.stringify(state.stocks));

    if (!newStocks[locationId]) newStocks[locationId] = {};
    const oldQty = newStocks[locationId][equipmentId] ?? 0;
    newStocks[locationId][equipmentId] = newQuantity;

    const loc = state.locations.find(l => l.id === locationId);
    const eq = state.equipments.find(e => e.id === equipmentId);

    const newMovement: MovementLog = {
      id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp,
      equipmentId,
      quantity: Math.abs(newQuantity - oldQty),
      fromLocationId: locationId,
      toLocationId: locationId,
      type: 'manual_audit',
      notes: `Ajustement d'inventaire : ${oldQty} -> ${newQuantity} (${reason})`,
    };

    const newState: AppState = {
      ...state,
      stocks: newStocks,
      movements: [newMovement, ...state.movements],
    };

    setState(newState);
    saveAppState(newState);
    showToast(`Stock recalé pour ${eq?.name.split('(')[0]} au ${loc?.name.split('(')[0]} : ${newQuantity} pièce(s).`);
  };

  // Open quick return with prefilled location and equipment
  const handleOpenQuickReturnWithParams = (fromLocId: string, eqId: string) => {
    setReturnFromLocId(fromLocId);
    setReturnEqId(eqId);
    setIsQuickReturnOpen(true);
  };

  // Open inter-base transfer with prefilled destination base and equipment
  const handleOpenInterBaseTransferWithParams = (toBaseId?: string, eqId?: string) => {
    setTransferToBaseId(toBaseId);
    setTransferEqId(eqId);
    setIsInterBaseTransferOpen(true);
  };

  // Critical shortages calculation for header badge (harmonized with DashboardView)
  const criticalAlertCount = state.locations
    .filter(l => (l.isInternalBase ?? l.type === 'patrol_base') && l.active !== false)
    .reduce((total, base) => {
      let count = 0;
      (state.equipments || []).filter(e => e.active !== false).forEach(eq => {
        const qty = state.stocks?.[base.id]?.[eq.id] ?? 0;
        const min = state.minThresholds?.[base.id]?.[eq.id] ?? eq.defaultMinThreshold;
        if (qty <= min) count++;
      });
      return total + count;
    }, 0);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white transition-colors">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-4 right-4 sm:left-auto sm:right-5 sm:bottom-5 z-50 animate-bounce duration-300">
          <div className={`p-3.5 sm:p-4 rounded-xl shadow-2xl border flex items-center justify-between sm:justify-start gap-3 text-xs sm:text-sm font-semibold ${
            toastMessage.type === 'warning'
              ? 'bg-amber-50 border-amber-300 text-amber-950 dark:bg-amber-950 dark:border-amber-600 dark:text-amber-200'
              : 'bg-emerald-50 border-emerald-300 text-emerald-950 dark:bg-emerald-950 dark:border-emerald-600 dark:text-emerald-200'
          }`}>
            <div className="flex items-center gap-2.5">
              {toastMessage.type === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              )}
              <span>{toastMessage.text}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white ml-2 p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewIncident={() => setIsNewIncidentOpen(true)}
        onOpenQuickReturn={() => {
          setReturnFromLocId(undefined);
          setReturnEqId(undefined);
          setIsQuickReturnOpen(true);
        }}
        onOpenInterBaseTransfer={() => {
          setTransferToBaseId(undefined);
          setTransferEqId(undefined);
          setIsInterBaseTransferOpen(true);
        }}
        onOpenWelcomeGuide={() => setIsWelcomeGuideOpen(true)}
        criticalAlertCount={criticalAlertCount}
      />

      {/* Main Container Viewport (avec espacement bas pour la barre mobile) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-2.5 sm:px-6 lg:px-8 py-3.5 sm:py-6 pb-28 md:pb-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            state={state}
            onOpenNewIncident={() => setIsNewIncidentOpen(true)}
            onOpenQuickReturnWithParams={handleOpenQuickReturnWithParams}
            onOpenQuickReturn={() => {
              setReturnFromLocId(undefined);
              setReturnEqId(undefined);
              setIsQuickReturnOpen(true);
            }}
            onOpenInterBaseTransfer={() => {
              setTransferToBaseId(undefined);
              setTransferEqId(undefined);
              setIsInterBaseTransferOpen(true);
            }}
            onOpenInterBaseTransferWithParams={handleOpenInterBaseTransferWithParams}
            onOpenWelcomeGuide={() => setIsWelcomeGuideOpen(true)}
          />
        )}

        {activeTab === 'closing' && (
          <ClosingRecoveryView
            state={state}
            onExecuteBulkRecovery={handleExecuteBulkRecovery}
            onOpenQuickReturnWithParams={handleOpenQuickReturnWithParams}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            state={state}
            onCancelIncident={handleCancelIncident}
            onUpdateMovement={handleUpdateMovement}
          />
        )}

        {activeTab === 'admin' && (
          <AdminView
            state={state}
            onUpdateState={newState => {
              setState(newState);
              saveAppState(newState);
              showToast('Configuration enregistrée avec succès.');
            }}
            onAuditStock={handleAuditStock}
          />
        )}
      </main>

      {/* Footer (avec espacement sur mobile pour ne pas être masqué par la barre d'onglets) */}
      <footer className="border-t border-slate-800/80 bg-slate-950/70 text-slate-500 text-xs py-4 mb-16 md:mb-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <span className="font-semibold text-slate-400">PisteMat</span>
            <span>&middot;</span>
            <span>Système de suivi opérationnel du matériel de secours sur pistes</span>
          </div>
          <div>
            <span>Conçu pour le service des pistes sans QR code ni budget d'équipement</span>
          </div>
        </div>
      </footer>

      {/* Modales Interactives */}
      <NewIncidentModal
        isOpen={isNewIncidentOpen}
        onClose={() => setIsNewIncidentOpen(false)}
        state={state}
        onSaveIncident={handleSaveIncident}
      />

      <QuickReturnModal
        isOpen={isQuickReturnOpen}
        onClose={() => setIsQuickReturnOpen(false)}
        state={state}
        onExecuteReturn={handleExecuteReturn}
        defaultFromLocationId={returnFromLocId}
        defaultEquipmentId={returnEqId}
      />

      <InterBaseTransferModal
        isOpen={isInterBaseTransferOpen}
        onClose={() => {
          setTransferToBaseId(undefined);
          setTransferEqId(undefined);
          setIsInterBaseTransferOpen(false);
        }}
        state={state}
        onExecuteTransfer={handleExecuteTransfer}
        defaultToBaseId={transferToBaseId}
        defaultEquipmentId={transferEqId}
      />

      <WelcomeGuideModal
        isOpen={isWelcomeGuideOpen}
        onClose={() => {
          localStorage.setItem('pistemat_welcome_seen', 'true');
          setIsWelcomeGuideOpen(false);
        }}
      />
    </div>
  );
}
