import { getAccessToken, googleSignIn } from './googleAuth';

export interface ExportResult {
  documentId: string;
  documentTitle: string;
  documentUrl: string;
}

export const exportImplementationPlanToGoogleDoc = async (
  onProgress?: (status: string) => void
): Promise<ExportResult> => {
  let token = await getAccessToken();

  if (!token) {
    if (onProgress) onProgress('Authentification avec votre compte Google...');
    const authResult = await googleSignIn();
    if (!authResult) {
      throw new Error('Connexion Google requise pour exporter vers Google Docs.');
    }
    token = authResult.accessToken;
  }

  if (onProgress) onProgress('Création du document Google Docs...');

  const title = `PisteMat - Plan d'Implémentation & Feuille de Route Déploiement (${new Date().toLocaleDateString('fr-FR')})`;

  // 1. Create document
  const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title }),
  });

  if (!createRes.ok) {
    const errorData = await createRes.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Erreur création document Docs: ${createRes.statusText}`
    );
  }

  const createdDoc = await createRes.json();
  const documentId = createdDoc.documentId;

  if (onProgress) onProgress('Rédaction du plan et de la feuille de route opérationnelle...');

  const fullContent = `PISTEMAT - SERVICE DES PISTES
PLAN D'IMPLÉMENTATION & FEUILLE DE ROUTE DE DÉPLOIEMENT INTERNE
Suivi Opérationnel & Déduction Automatique du Matériel de Secours
Date de génération : ${new Date().toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}

================================================================================
SYNTHÈSE DES DÉCISIONS OPÉRATIONNELLES
================================================================================

1. AUCUN ÉTIQUETAGE NI QR CODE SUR LE TERRAIN
   Les pisteurs-secouristes se concentrent à 100% sur le blessé et les conditions de montagne. Le matériel n'est pas scanné ni numéroté sur les pistes.

2. DÉDUCTION AUTOMATIQUE CLINIQUEMENT PILOTÉE
   L'enregistrement d'une fiche secours (15 secondes chrono : poste, type de blessure, destination d'évacuation) déduit automatiquement le matériel standard mobilisé (MID, attelles, colliers).

3. COMPTABILITÉ PAR JAUGES ET LIEUX GÉOGRAPHIQUES
   Suivi en temps réel des stocks disponibles par poste de secours d'altitude et suivi exact des matériels retenus à l'extérieur (Cabinet Médical de station, Urgences Hôpital de vallée, Atelier révision).

4. GESTION NO-CODE INTÉGRÉE POUR LES RESPONSABLES
   Les chefs de secteur et l'administration peuvent ajouter, modifier ou supprimer des postes, du matériel ou des règles de déduction sans toucher au code informatique.

5. PROCESSUS DE FERMETURE DES PISTES & RAPATRIEMENT
   Module dédié en fin de journée récapitulant les matériels à récupérer d'urgence avant la fermeture des remontées mécaniques, avec validation en 1 clic.

6. SIGNALEMENT DES AVARIES EN 1 CLIC
   Possibilité d'isoler immédiatement tout équipement détérioré ou percé vers l'atelier de révision.

================================================================================
1. VUE D'ENSEMBLE DU PROJET & BÉNÉFICES MÉTIER
================================================================================

Contexte :
Au service des pistes, le matériel d'immobilisation de secours (Matelas Immobilisateur à Dépression - MID, colliers cervicaux, attelles de membre gonflables ou alu) quitte fréquemment la station pour descendre chez les médecins ou aux urgences de la vallée avec les blessés.

Problématique résolue :
L'équipe d'accueil et administrative manquait d'une visibilité en temps réel sur les stocks réels dans chaque poste et sur ce qui devait être récupéré. Les solutions de QR codes ou de numérotation physique s'étant révélées inadaptées au froid et à l'urgence, PisteMat résout l'équation par la déduction clinique automatique.

Bénéfices majeurs :
- Zéro charge mentale pour les pisteurs sur le terrain.
- Visibilité infaillible sur les jauges et alertes de rupture imminente.
- Tournées de rapatriement ciblées à 100% (savoir exactement quoi réclamer au cabinet médical ou à l'hôpital).
- Données consolidées pour les bilans de fin de saison et le budget communal.

================================================================================
2. LES MODULES DE L'APPLICATION
================================================================================

Module 1 : TABLEAU DE BORD SITUATION OPÉRATIONNELLE
- Vue cartouche de tous les postes de secours de la station (Poste Central, Postes d'Altitude).
- Jauges de niveau par équipement (MID, colliers, attelles, plan dur).
- Détection et signalisation visuelle des seuils d'alerte critique.
- Volet « Matériel en Extérieur » chiffrant les unités chez le Médecin, aux Urgences ou en Réparation.

Module 2 : SAISIE ÉCLAIR DES SECOURS (15 SECONDES)
- Prise de message radio intuitive :
  * Poste d'origine de l'intervention
  * Type de blessure (Rachis/dos, Fracture fémur/jambe, Membre supérieur, Polytraumatisme, etc.)
  * Mode d'évacuation : Trajet direct (hélicoptère / hôpital) ou Transit par le Poste Central d'accueil
  * Déduction visuelle instantanée des équipements avec ajustement manuel en un clic (+ / -)

Module 3 : FERMETURE DES PISTES & CLÔTURE DU JOUR
- Checklist opérationnelle de fin de journée :
  * Matériel en souffrance au Cabinet Médical de station
  * Matériel descendu en vallée au CHU / SAMU
- Bouton « Valider tournée de récupération » pour réintégrer le matériel rapatrié au Poste Central.

Module 4 : CENTRE DE RAPATRIEMENT & GESTION DES AVARIES
- Réintégration en un clic dès qu'une navette ou une ambulance ramène du matériel.
- Bouton d'avarie : transfert immédiat vers l'Atelier avec motif (fuite valve, sangle arrachée).

Module 5 : ESPACE ADMINISTRATION NO-CODE (POUR LES RESPONSABLES)
- Gestion des Postes et Lieux : ajout, modification de nom, altitude et coordonnées radio.
- Catalogue du Matériel : création de nouvelles références et seuils d'alerte.
- Matrice de Déduction : personnalisation des correspondances entre blessures et matériel requis.
- Recalibrage d'Inventaire : pointage du matin avec saisie d'un motif pour réaligner le réel.
- Sauvegarde Complète : export et restauration JSON de saison.

Module 6 : MAIN COURANTE & EXPORTS EXCEL / CSV
- Journal chronologique et horodaté de tous les flux (secours, rapatriements, réparations).
- Générateur d'export CSV compatible Microsoft Excel avec encodage UTF-8 et point-virgule.

================================================================================
3. FEUILLE DE ROUTE ÉTAPE PAR ÉTAPE : CRÉATION & DÉPLOIEMENT INTERNE
================================================================================

ÉTAPE 1 : DÉVELOPPEMENT & ASSEMBLAGE TECHNIQUE (Semaine 1)
- Validation des écrans interactifs et du moteur de déduction automatique.
- Mise en place de la persistance locale et de la synchronisation instantanée inter-postes.
- Intégration de l'export Google Docs et du générateur CSV/Excel.

ÉTAPE 2 : PARAMÉTRAGE INITIAL DES DONNÉES RÉELLES (Semaine 2)
- Renseigner la liste exacte des postes de la station et leurs altitudes.
- Saisir l'inventaire physique de départ pour chaque type de matériel.
- Configurer les seuils d'alerte rouge par secteur.

ÉTAPE 3 : PRÉSENTATION & VALIDATION AVEC LES CHEFS DES PISTES (Semaine 2)
- Démonstration sur grand écran du formulaire de saisie en 15 secondes.
- Présentation de l'espace No-Code aux responsables pour leur montrer leur autonomie complète.
- Validation des formats de rapports souhaités pour la direction et la mairie.

ÉTAPE 4 : PHASE PILOTE DE RODAGE SUR LE TERRAIN (Semaine 3)
- Utilisation à l'accueil en doublon avec la main courante papier/radio habituelle pendant 1 semaine.
- Comparaison quotidienne à la fermeture entre les déductions de l'app et les retours physiques.
- Ajustement fin des règles de déduction dans l'espace No-Code.

ÉTAPE 5 : DÉPLOIEMENT SUR LE RÉSEAU INTERNE DE LA STATION (Semaine 4)
- Mise à disposition sur tous les ordinateurs (Accueil, Régulation, Postes d'altitude).
- Création d'un raccourci direct sur le bureau des PC.
- Fonctionnement fluide sans installation lourde depuis le navigateur web.

ÉTAPE 6 : FORMATION RAPIDE & SUIVI DE SAISON (En continu)
- Mini-formation de 5 minutes pour les collègues d'accueil.
- Information des pisteurs sur le bon déroulement des rapatriements du soir.
- Export du bilan de fin de saison pour anticiper les investissements de l'hiver suivant.

================================================================================
Document produit automatiquement par l'application PisteMat.
Exporté vers Google Docs pour transmission à la direction et aux chefs de secteur.
================================================================================
`;

  // 2. Insert formatted content via batchUpdate
  const updateRes = await fetch(
    `https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              location: {
                index: 1,
              },
              text: fullContent,
            },
          },
        ],
      }),
    }
  );

  if (!updateRes.ok) {
    const errorData = await updateRes.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Erreur d'insertion dans le document: ${updateRes.statusText}`
    );
  }

  if (onProgress) onProgress('Finalisation du document Google Docs...');

  return {
    documentId,
    documentTitle: title,
    documentUrl: `https://docs.google.com/document/d/${documentId}/edit`,
  };
};
