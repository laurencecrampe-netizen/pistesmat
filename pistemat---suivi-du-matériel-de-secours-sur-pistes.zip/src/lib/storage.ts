import { AppState, MovementLog, Equipment, Location, RescueIncident } from '../types';
import { getInitialAppState } from './defaultData';

const STORAGE_KEY = 'pistemat_app_state_v1';
const BROADCAST_CHANNEL = 'pistemat_sync_channel';

let channel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    channel = new BroadcastChannel(BROADCAST_CHANNEL);
  }
} catch (e) {
  console.warn('BroadcastChannel non supporté ou bloqué:', e);
}

export const loadAppState = (): AppState => {
  const initial = getInitialAppState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveAppState(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);

    // Schema integrity check
    if (!parsed || typeof parsed !== 'object') {
      saveAppState(initial);
      return initial;
    }

    const mergedStocks: Record<string, Record<string, number>> = { ...initial.stocks };
    if (parsed.stocks && typeof parsed.stocks === 'object') {
      Object.keys(parsed.stocks).forEach(locId => {
        mergedStocks[locId] = { ...(initial.stocks[locId] || {}), ...parsed.stocks[locId] };
      });
    }

    const mergedMinThresholds: Record<string, Record<string, number>> = { ...initial.minThresholds };
    if (parsed.minThresholds && typeof parsed.minThresholds === 'object') {
      Object.keys(parsed.minThresholds).forEach(locId => {
        mergedMinThresholds[locId] = { ...(initial.minThresholds[locId] || {}), ...parsed.minThresholds[locId] };
      });
    }

    let deductionRules = Array.isArray(parsed.deductionRules) && parsed.deductionRules.length > 0 ? parsed.deductionRules : initial.deductionRules;
    if (!deductionRules.some((r: any) => r.injuryKey === 'sans_materiel')) {
      const sansMat = initial.deductionRules.find(r => r.injuryKey === 'sans_materiel');
      if (sansMat) {
        deductionRules = [sansMat, ...deductionRules];
      }
    }

    const state: AppState = {
      locations: Array.isArray(parsed.locations) && parsed.locations.length > 0 ? parsed.locations : initial.locations,
      equipments: Array.isArray(parsed.equipments) && parsed.equipments.length > 0 ? parsed.equipments : initial.equipments,
      deductionRules,
      incidents: Array.isArray(parsed.incidents) ? parsed.incidents : initial.incidents,
      movements: Array.isArray(parsed.movements) ? parsed.movements : initial.movements,
      stocks: mergedStocks,
      minThresholds: mergedMinThresholds,
    };

    return state;
  } catch (error) {
    console.error('Erreur lecture localStorage, réinitialisation par défaut:', error);
    return initial;
  }
};

export const saveAppState = (state: AppState): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    if (channel) {
      channel.postMessage({ type: 'STATE_UPDATED', timestamp: Date.now() });
    }
  } catch (error) {
    console.error('Erreur sauvegarde localStorage:', error);
  }
};

export const subscribeToStateChanges = (callback: () => void): (() => void) => {
  if (!channel) return () => {};
  const handler = (event: MessageEvent) => {
    if (event.data?.type === 'STATE_UPDATED') {
      callback();
    }
  };
  channel.addEventListener('message', handler);
  return () => {
    channel?.removeEventListener('message', handler);
  };
};

// Generates Excel-friendly CSV with UTF-8 BOM and semicolon delimiters
export const exportMovementsToCSV = (
  movements: MovementLog[],
  equipments: Equipment[],
  locations: Location[],
  incidents?: RescueIncident[]
): void => {
  const eqMap = new Map(equipments.map(e => [e.id, e.name]));
  const locMap = new Map(locations.map(l => [l.id, l.name]));
  const incMap = new Map((incidents || []).map(i => [i.id, i.number]));

  const headers = [
    'Date & Heure',
    'Type d Événement',
    'Matériel',
    'Quantité',
    'Lieu d Origine',
    'Lieu de Destination',
    'Secours Associé',
    'Notes / Motifs',
  ];

  const typeLabels: Record<string, string> = {
    rescue_dispatch: 'Secours - Déduction',
    rescue_transit: 'Transit Secours',
    quick_return: 'Rapatriement Rapide',
    closing_recovery: 'Tournée Fermeture Pistes',
    inter_base_transfer: 'Renfort Inter-Postes',
    incident_cancellation: 'Annulation Secours',
    flagged_damaged: 'Signalement Avarie / Atelier',
    maintenance_repaired: 'Retour de Réparation',
    manual_audit: 'Ajustement Inventaire Manuel',
  };

  const rows = movements.map(m => {
    let incidentDisplay = '-';
    if (m.incidentId) {
      const num = incMap.get(m.incidentId);
      incidentDisplay = num !== undefined ? `Secours #${num}` : `Secours #${m.incidentId.replace('inc_', '')}`;
    }

    return [
      new Date(m.timestamp).toLocaleString('fr-FR'),
      typeLabels[m.type] || m.type,
      eqMap.get(m.equipmentId) || m.equipmentId,
      m.quantity.toString(),
      locMap.get(m.fromLocationId) || m.fromLocationId,
      locMap.get(m.toLocationId) || m.toLocationId,
      incidentDisplay,
      `"${(m.notes || '').replace(/"/g, '""')}"`,
    ];
  });

  const csvContent =
    '\uFEFF' + // UTF-8 BOM for Microsoft Excel
    [headers.join(';'), ...rows.map(r => r.join(';'))].join('\r\n');

  downloadBlob(
    csvContent,
    `pistemat_main_courante_${new Date().toISOString().slice(0, 10)}.csv`,
    'text/csv;charset=utf-8;'
  );
};

export const exportStockInventoryToCSV = (
  state: AppState
): void => {
  const { locations, equipments, stocks, minThresholds } = state;
  const headers = ['Lieu / Poste', 'Catégorie Lieu', 'Matériel', 'En Stock', 'Seuil Alerte', 'Statut'];

  const rows: string[][] = [];

  locations.forEach(loc => {
    equipments.forEach(eq => {
      const qty = stocks[loc.id]?.[eq.id] ?? 0;
      const min = minThresholds[loc.id]?.[eq.id] ?? 0;
      let status = 'Nominal';
      if (loc.isInternalBase) {
        if (qty === 0) status = 'RUPTURE CRITIQUE';
        else if (qty <= min) status = 'Seuil Alerte Atteint';
      } else {
        status = qty > 0 ? 'En détention extérieure' : 'Vide';
      }

      rows.push([
        `"${loc.name}"`,
        loc.isInternalBase ? 'Poste de Secours' : 'Lieu Externe / Soin',
        `"${eq.name}"`,
        qty.toString(),
        loc.isInternalBase ? min.toString() : '-',
        status,
      ]);
    });
  });

  const csvContent =
    '\uFEFF' +
    [headers.join(';'), ...rows.map(r => r.join(';'))].join('\r\n');

  downloadBlob(
    csvContent,
    `pistemat_etat_des_stocks_${new Date().toISOString().slice(0, 10)}.csv`,
    'text/csv;charset=utf-8;'
  );
};

export const exportFullJSONBackup = (state: AppState): void => {
  const jsonContent = JSON.stringify(state, null, 2);
  downloadBlob(
    jsonContent,
    `pistemat_sauvegarde_complete_${new Date().toISOString().slice(0, 10)}.json`,
    'application/json'
  );
};

const downloadBlob = (content: string, filename: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
