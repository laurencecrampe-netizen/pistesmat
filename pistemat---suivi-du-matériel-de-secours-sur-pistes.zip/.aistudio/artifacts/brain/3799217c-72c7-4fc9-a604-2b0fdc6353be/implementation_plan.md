# Plan d'Amélioration Ergonomique et Lisibilité (PisteMat)

Ce plan détaille les propositions d'amélioration ergonomique, de contraste et d'expérience utilisateur suite à vos réponses aux questions d'orientation. **Aucune modification du code source de l'application n'a été effectuée** conformément à votre consigne.

---

## 1. Objectifs & Réponses Utilisateur

- **Orientation de contraste :** Ajout d'un bouton pour basculer facilement entre **Mode Clair** (haute lisibilité en plein jour / bureau) et **Mode Sombre** (optimisé pour faible éclairage).
- **Densité & Typographie :** Textes agrandis, interlignages aérés, espacements accrus et cartes aux bordures nettes et bien découpées.
- **Alertes & Statuts :** Badges de statut et alertes de stock critique (niveaux mini / rupture) avec un code couleur plus vif, percutant et contrasté.

---

## 2. Détail des Améliorations Proposées

### A. Sélecteur de Thème Clair / Sombre (Header)
- **Emplacement :** Un bouton discret mais immédiatement accessible dans le bandeau supérieur (icône Soleil ☀️ / Lune 🌙), disponible sur ordinateur et sur mobile.
- **Persistance :** Le choix de l'utilisateur est automatiquement mémorisé dans le navigateur (`localStorage`).
- **Comportement des deux modes :**
  - **Mode Clair (Recommandé pour la lisibilité) :**
    - Fond général : Gris perle / neige doux (`bg-slate-100` / `bg-slate-50`).
    - Cartes et panneaux : Blanc pur (`bg-white`) avec bordures franches (`border-slate-300`) et ombre douce.
    - Textes : Noir profond (`text-slate-900`) et gris foncé (`text-slate-700`), éliminant les textes gris délavés difficiles à lire.
  - **Mode Sombre (Revitalisé et contrasté) :**
    - Fin des gris moyens illisibles : fond sombre profond (`bg-slate-950`), cartes distinctes (`bg-slate-900`), bordures claires (`border-slate-700`).
    - Textes blancs purs (`text-white`) et sous-titres contrastés (`text-slate-200`).

### B. Lisibilité Typographique et Espaces Aérés
- **Augmentation des tailles de texte :**
  - Fin des textes minuscules (10px–11px) : passage à une taille minimale de 13px–14px pour les libellés secondaires.
  - Les titres de cartes et postes passent à 16px–18px en gras net.
- **Chiffres et compteurs de matériel :**
  - Affichage en chiffres tabulaires (`tabular-nums font-bold text-lg`), assurant un alignement parfait sans décalage.
- **Respiration des cartes :**
  - Augmentation des marges intérieures (`padding`) pour que les informations ne soient plus tassées.
  - Séparateurs nets entre chaque zone pour repérer les postes de secours et leurs matériels en un coup d'œil.

### C. Badges de Statuts et Alertes Visuelles Renforcées
- **Alertes de stock :**
  - **Stock critique / Rupture :** Badge rouge vif contrasté (`bg-rose-100 text-rose-900 border-rose-300` en mode clair, `bg-rose-950 text-rose-200 border-rose-700` en mode sombre) avec icône d'alerte explicite.
  - **Stock bas / Attention :** Badge ambre dynamique (`bg-amber-100 text-amber-900 border-amber-300`).
  - **Stock nominal :** Badge émeraude apaisant (`bg-emerald-100 text-emerald-900 border-emerald-300`).
- **Boutons d'action opérationnelle :**
  - Les boutons clés (*Nouveau Secours*, *Rapatriement*, *Réapprovisionner*) conservent leurs repères visuels distincts (rouge secours, vert rapatriement, bleu transfert) avec un contraste de texte maximal pour être cliquables sans hésitation même avec des gants ou sur tablette.

---

## 3. Plan de Validation & Recette

1. **Test du commutateur de thème :** Vérifier la bascule instantanée Clair $\leftrightarrow$ Sombre sur toutes les vues (*Postes & Stocks*, *Fermeture 17h*, *Main Courante*, *Administration* et modales de saisie).
2. **Contrôle du contraste WCAG AA :** Vérifier que tous les textes, libellés et badges offrent un contraste supérieur à 4.5:1 sur leur fond respectif.
3. **Ergonomie mobile et ordinateur :** S'assurer que les boutons restent parfaitement cadrés dans la trame, sans débordement, avec des zones tactiles confortables ($\ge 44\text{px}$).
4. **Vérification de la persistance :** Rafraîchissement de la page pour confirmer que le thème choisi reste actif.
